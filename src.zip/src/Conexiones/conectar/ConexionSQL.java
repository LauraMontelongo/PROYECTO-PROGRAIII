package Conexiones.conectar;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class ConexionSQL {
        Connection conn=null;
    public Connection conexion(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/inventario","root","");
            
            System.out.println("Conectado");
            
        }catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "No Conectado");
        }
     return conn;
    }
}
