/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectofinal178646177291;

/**
 *
 * @author Uriel Monreal
 */
public class ProyectoFinal178646177291 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        VentanaPrincipal v1 = new VentanaPrincipal();
        v1.setVisible(true);

        
    }
    
}
