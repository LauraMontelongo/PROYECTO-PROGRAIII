package proyectofinal178646177291;


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class EliminarProductos extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public EliminarProductos() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos("");
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        ElimM = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabElimP = new javax.swing.JTable();
        lColor1 = new javax.swing.JLabel();
        lColor2 = new javax.swing.JLabel();
        ElimMod = new javax.swing.JTextField();
        lColor3 = new javax.swing.JLabel();
        ElimTalla = new javax.swing.JTextField();
        ElimColor = new javax.swing.JTextField();
        lColor4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Eliminar Productos");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(460, 10, 160, 50);

        ElimM.setBackground(new java.awt.Color(204, 204, 204));
        ElimM.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimMActionPerformed(evt);
            }
        });
        jPanel1.add(ElimM);
        ElimM.setBounds(150, 170, 170, 22);

        btnEliminar.setBackground(new java.awt.Color(255, 204, 0));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar);
        btnEliminar.setBounds(150, 420, 130, 30);

        btnVolver.setBackground(new java.awt.Color(255, 204, 0));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(20, 420, 110, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondorojo.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(400, 20, 260, 30);

        tabElimP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Marca", "Modelo", "Color", "Talla", "Precio", "Cantidad"
            }
        ));
        tabElimP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabElimPMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabElimP);
        if (tabElimP.getColumnModel().getColumnCount() > 0) {
            tabElimP.getColumnModel().getColumn(0).setPreferredWidth(40);
            tabElimP.getColumnModel().getColumn(2).setPreferredWidth(7);
            tabElimP.getColumnModel().getColumn(3).setPreferredWidth(12);
            tabElimP.getColumnModel().getColumn(4).setPreferredWidth(9);
            tabElimP.getColumnModel().getColumn(5).setPreferredWidth(12);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(340, 70, 800, 402);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setText("*Modelo");
        jPanel1.add(lColor1);
        lColor1.setBounds(60, 220, 80, 20);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setText("* Marca: ");
        jPanel1.add(lColor2);
        lColor2.setBounds(60, 170, 80, 20);

        ElimMod.setBackground(new java.awt.Color(204, 204, 204));
        ElimMod.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimModActionPerformed(evt);
            }
        });
        jPanel1.add(ElimMod);
        ElimMod.setBounds(150, 220, 170, 22);

        lColor3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor3.setText("*Talla");
        jPanel1.add(lColor3);
        lColor3.setBounds(60, 270, 80, 20);

        ElimTalla.setBackground(new java.awt.Color(204, 204, 204));
        ElimTalla.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimTalla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimTallaActionPerformed(evt);
            }
        });
        jPanel1.add(ElimTalla);
        ElimTalla.setBounds(150, 270, 170, 22);

        ElimColor.setBackground(new java.awt.Color(204, 204, 204));
        ElimColor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimColor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimColorActionPerformed(evt);
            }
        });
        jPanel1.add(ElimColor);
        ElimColor.setBounds(150, 320, 170, 22);

        lColor4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor4.setText("*Color");
        jPanel1.add(lColor4);
        lColor4.setBounds(60, 320, 80, 20);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoEliminar.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1260, 490);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1167, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
        String[] titulos={"Marca","Modelo","Color","Talla","Precio","Cantidad"};
        String[] reg=new String[6];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from productos";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("marca");
                reg[1]=rs.getString("modelo");
                reg[2]=rs.getString("color");
                reg[3]=rs.getString("talla");
                reg[4]=rs.getString("precio");
                reg[5]=rs.getString("cantidad");
                
                mod.addRow(reg);
            }
            tabElimP.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void Eliminar(){
         int fila=tabElimP.getSelectedRow();
        if(fila>=0){
            ElimM.setText(tabElimP.getValueAt(fila, 0).toString());
            ElimMod.setText(tabElimP.getValueAt(fila, 1).toString());
            ElimTalla.setText(tabElimP.getValueAt(fila, 3).toString());
            ElimColor.setText(tabElimP.getValueAt(fila, 2).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }

    public void mostrarDatos(){
        String[] titulos={"Marca","Modelo","Color","Talla","Precio","Cantidad"};
        String[] reg=new String[6];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from productos";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("marca");
                reg[1]=rs.getString("modelo");
                reg[2]=rs.getString("color");
                reg[3]=rs.getString("talla");
                reg[4]=rs.getString("precio");
                reg[5]=rs.getString("cantidad");
                
                mod.addRow(reg);
            }
            tabElimP.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        java.sql.Statement ss; 
        String user = ElimM.getText();
        String pass = ElimMod.getText();
        String talla = ElimTalla.getText();
        String color = ElimColor.getText();
        try {
            ss = con.createStatement();
            String sql="DELETE FROM productos WHERE marca='"+user+"'and modelo='"+pass+"'and talla='"+talla+"'and color='"+color+"' ";
            ss.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "ACTUALIZADO");
            mostrarDatos();
       
        } catch (SQLException ex) {
            Logger.getLogger(EliminarProductos.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERROR NO SE PUDO ELIMINAR");
        }
        
        ElimM.setText(null);
        ElimMod.setText(null);
        ElimTalla.setText(null);
        ElimColor.setText(null);
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabElimPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabElimPMouseClicked
        Eliminar();
    }//GEN-LAST:event_tabElimPMouseClicked

    private void ElimMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimMActionPerformed

    private void ElimModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimModActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimModActionPerformed

    private void ElimTallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimTallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimTallaActionPerformed

    private void ElimColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimColorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimColorActionPerformed
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ElimColor;
    private javax.swing.JTextField ElimM;
    private javax.swing.JTextField ElimMod;
    private javax.swing.JTextField ElimTalla;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lColor3;
    private javax.swing.JLabel lColor4;
    private javax.swing.JTable tabElimP;
    // End of variables declaration//GEN-END:variables
}
