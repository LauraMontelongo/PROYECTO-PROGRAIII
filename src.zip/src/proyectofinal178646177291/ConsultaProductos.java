package proyectofinal178646177291;


/*
   FRAME que contiene la consulta de todos los AdminisProductos Disponibles en nuestro almacen
*/
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import Conexiones.conectar.ConexionSQL;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;

public class ConsultaProductos extends javax.swing.JFrame {

    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    
    public ConsultaProductos() {
        initComponents();
        checarSiesCero();
        mostrarDatos();
    }

        
    public void checarSiesCero(){
         java.sql.Statement ss;
         String SQL = "SELECT * FROM productos  WHERE cantidad='"+0+"'";
         try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            if (rs.next()) {
                int cant = Integer.parseInt(rs.getString("cantidad"));
                if (cant == 0) {
                    JOptionPane.showMessageDialog(null, "ALERTA! UN PRODUCTO(S) SE QUEDO SIN MERCANCÍA");
                } 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        btnGrafic = new javax.swing.JButton();
        btnPdF = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("CONSULTA DE PRODUCTOS");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(380, 20, 240, 50);

        btnVolver.setBackground(new java.awt.Color(255, 102, 102));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(30, 410, 100, 23);

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Marca", "Modelo", "Color", "Talla", "Precio", "Cantidad"
            }
        ));
        jScrollPane1.setViewportView(tablaProductos);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 1040, 330);

        btnGrafic.setBackground(new java.awt.Color(255, 102, 102));
        btnGrafic.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnGrafic.setText("Gráficar");
        btnGrafic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGraficActionPerformed(evt);
            }
        });
        jPanel1.add(btnGrafic);
        btnGrafic.setBounds(150, 410, 100, 23);

        btnPdF.setBackground(new java.awt.Color(255, 102, 102));
        btnPdF.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPdF.setText("PDF");
        btnPdF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPdFActionPerformed(evt);
            }
        });
        jPanel1.add(btnPdF);
        btnPdF.setBounds(260, 410, 100, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoConsultasA.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1090, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1081, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnGraficActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGraficActionPerformed
        GraficadeProductos menu = new GraficadeProductos();
        menu.graficar();
    }//GEN-LAST:event_btnGraficActionPerformed

    private void btnPdFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPdFActionPerformed
          Document documento3 = new Document();
       
        try {
            String ruta = System.getProperty("user.home");
            PdfWriter.getInstance(documento3, new FileOutputStream(ruta + "/Downloads/Reporte_Productos.pdf"));
            documento3.open();
            
            
            //TITULO DEL PDF
            Font font = new Font(Font.FontFamily.TIMES_ROMAN, 24, Font.BOLD,BaseColor.BLUE);
            Paragraph title = new Paragraph("REPORTE DE PRODUCTOS ALMACEN", font);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            documento3.add(title);
            
            //AGREGAMOS UN ESPACIO
            Paragraph espacio = new Paragraph(" ", font);
            documento3.add(espacio);
            
            PdfPTable tabla = new PdfPTable(6);
            tabla.addCell("Marca");
            tabla.addCell("Modelo");
            tabla.addCell("Color");
            tabla.addCell("Talla");
            tabla.addCell("Precio");
            tabla.addCell("Cantidad");
            
            
             
            try {
               
                String SQL="select * from productos";
        
        
                java.sql.Statement s = con.createStatement(); 
                java.sql.ResultSet rs = s.executeQuery (SQL);
                
                if(rs.next()){
                                       
                    do {                        
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                        tabla.addCell(rs.getString(5));
                        tabla.addCell(rs.getString(6));
                    } while (rs.next());
                    documento3.add(tabla);                    
                }
                
            } catch (DocumentException | SQLException e) {
            }
            documento3.close();
            JOptionPane.showMessageDialog(null, "Pdf Exitoso!");
        } catch (DocumentException | HeadlessException | FileNotFoundException e) {
        }
    }//GEN-LAST:event_btnPdFActionPerformed

    public void mostrarDatos(){
        String[] titulos={"Marca","Modelo","Color","Talla","Precio","Cantidad"};
        String[] reg=new String[6];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from productos";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("marca");
                reg[1]=rs.getString("modelo");
                reg[2]=rs.getString("color");
                reg[3]=rs.getString("talla");
                reg[4]=rs.getString("precio");
                reg[5]=rs.getString("cantidad");
                
                mod.addRow(reg);
            }
            tablaProductos.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGrafic;
    private javax.swing.JButton btnPdF;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaProductos;
    // End of variables declaration//GEN-END:variables
}
