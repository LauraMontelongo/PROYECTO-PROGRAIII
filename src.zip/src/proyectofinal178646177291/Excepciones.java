/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal178646177291;

import javax.swing.JTextField;

/**
 * En esta clase se guardan todas las Excepciones Propias que implementamos en el proyecto
 */


public class Excepciones {
      public void noMinusculas(String e, JTextField f) throws Exception{
        
        if (e.matches("[A-Z0-9]+")) {
                
                e = f.getText();                
            
        } else {

            throw new Exception();

        }
        
    }
    
    public void noMayusculas(String e, JTextField f) throws Exception{
        
        if (e.matches("[a-z0-9]+")) {
                
            e = f.getText();                
            
        } else {

            throw new Exception();

        }
        
    }
    
    public void noNumeros(String e, JTextField f) throws Exception{
        
        if (e.matches("[a-zA-Z]+")) {
                
            e = f.getText();                
            
        } else {

            throw new Exception();

        }
        
    }
    
    public void Largo(String e, JTextField f) throws Exception{
        
        if (e.length() <= 8) {
                
            e = f.getText();                
            
        } else {

            throw new Exception();

        }
        
    }
    
    public void Enteros(String e, JTextField f) throws Exception{
                 
        if (e.matches("[0-9]+")) {
                
            e = f.getText();                
            
        } else {

            throw new Exception();

        }
        
    }
}
