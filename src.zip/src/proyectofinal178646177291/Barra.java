/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal178646177291;

/**
 *
 * @author Uriel Monreal
 */

import javax.swing.JProgressBar;

public class Barra extends Thread{
    
    JProgressBar progress;
    
     public Barra(JProgressBar progress){
        super();
        this.progress = progress; 
    }
    
     //HILO
     /*
       En un hilo se sobreescribe le metodo "run"
     */
    @Override
    public void run(){
         /*
C          Como la barra termina de cargarse cuando llega a 100 
           Implementamos el siguiente for para controlar eso
        */
         
        for (int i = 1; i <= 100; i++) {
            //Le vamos a ir Asignando un valor a la barra de Progreso Hasta el 100
            progress.setValue(i);
            //Se va a Terminar el proceso cuando este llegue a 30 Mili segundos
            pausa(30);
        }
    }
    
    //Metodo Paara Pausar La Barra De Progreso
    //Se lleva como parametro los Mili segundos en los cuales parará el Proceso
    public void pausa(int mlSeg){
        try {
            /*
              NOTA:
              "Thread.sleep": Suspende el subproceso actual durante el 
              número de milisegundos especificado.
            */
                    
            Thread.sleep(mlSeg);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
}
