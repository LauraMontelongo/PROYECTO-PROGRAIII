package proyectofinal178646177291;

/*
   FRAME que contiene la opción de poder comprar lo que el usuario tenga en su carrito
   esto atráves del Codigo de Venta
*/

//LIBRERIAS
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;
//PARA EL PDF
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;

import Conexiones.conectar.ConexionSQL;


public class ComprarDelCarrito extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public ComprarDelCarrito() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    
    public void mostrarDatos(String Nombre){
        //Obtenemos los valores de los Text Field
        String cod = codigoVenta.getText();
        String marcas = marca.getText();
        String model = modelo.getText();
        String tallaa = talla.getText();
        String colors = color.getText();
        //Arreglo para los titulos de la tabla
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        /*A una TableModel(Tabla donde se mostraran los registros le agreamos los encabezados"Titulos"
          de la tabla
        */
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        /*Escribimos la sentencia que queremos llevar a cabo en este caso "select" porque solo vamos a consultar/
          imprimir y *from es la tabla de la base de datos donde tomaremos los valos con la condición que el
          campo de "codigoVenta de la base de datos sea igual al que guardo en el Text Fiel
        */
        String SQL="select * from carrocompras WHERE  codigoVenta='"+cod+"' ";
        
        try{
            //Se crea la "sentencia"
            java.sql.Statement s = con.createStatement(); 
            //Se ejecuta
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            //Mientras se ejcute se guarda en un arreglo todos los valores de esos campos
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                mod.addRow(reg);//Esos datos se van a meter a "model"
            }
            tabCarritoA.setModel(mod);//Se ponen en nuestra Tabla
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    /*Esta función se lleva a cabo cuando se toca un dato de la tabla..
      Despues de tocarlo en los TextField se colocará la información de esa fila que se selecciono
    */
     public void modificar(){
        int fila=tabCarritoA.getSelectedRow();
        if(fila>=0){
            /*A nuestro Text Field se le va a asignar como información lo que está en 
            la fila (n) de nuestra tabla*/
            codV.setText(tabCarritoA.getValueAt(fila, 0).toString());
            codigoVenta.setText(tabCarritoA.getValueAt(fila, 0).toString());
            nomU.setText(tabCarritoA.getValueAt(fila, 1).toString());
            contra.setText(tabCarritoA.getValueAt(fila, 2).toString());
            color.setText(tabCarritoA.getValueAt(fila, 3).toString());
            marca.setText(tabCarritoA.getValueAt(fila, 4).toString());
            modelo.setText(tabCarritoA.getValueAt(fila, 5).toString());
            talla.setText(tabCarritoA.getValueAt(fila, 6).toString());
            cantidad.setText(tabCarritoA.getValueAt(fila, 7).toString());
            cantPagar.setText(tabCarritoA.getValueAt(fila, 8).toString());
            totalPagar.setText(tabCarritoA.getValueAt(fila, 9).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
        
       
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCarritoA = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        lColor = new javax.swing.JLabel();
        codigoVenta = new javax.swing.JTextField();
        lTalla4 = new javax.swing.JLabel();
        codV = new javax.swing.JTextField();
        contra = new javax.swing.JTextField();
        lTalla5 = new javax.swing.JLabel();
        nomU = new javax.swing.JTextField();
        lTalla6 = new javax.swing.JLabel();
        lTalla7 = new javax.swing.JLabel();
        color = new javax.swing.JTextField();
        lTalla8 = new javax.swing.JLabel();
        marca = new javax.swing.JTextField();
        lTalla9 = new javax.swing.JLabel();
        modelo = new javax.swing.JTextField();
        lTalla10 = new javax.swing.JLabel();
        talla = new javax.swing.JTextField();
        lTalla11 = new javax.swing.JLabel();
        cantPagar = new javax.swing.JTextField();
        btnComprar = new javax.swing.JButton();
        lTalla12 = new javax.swing.JLabel();
        cantidad = new javax.swing.JTextField();
        lTalla13 = new javax.swing.JLabel();
        totalPagar = new javax.swing.JTextField();
        MostrarDatos = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("COMPRAR CARRITO");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(500, 30, 240, 30);

        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(930, 490, 100, 23);

        tabCarritoA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Marca", "Modelo", "Color", "Talla", "Precio", "Cantidad"
            }
        ));
        tabCarritoA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabCarritoAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabCarritoA);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(340, 180, 730, 290);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(460, 20, 280, 50);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setForeground(new java.awt.Color(255, 255, 255));
        lColor.setText("*Código Venta:");
        jPanel1.add(lColor);
        lColor.setBounds(460, 110, 190, 20);

        codigoVenta.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.add(codigoVenta);
        codigoVenta.setBounds(560, 110, 190, 22);

        lTalla4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla4.setText("Codigo Venta");
        jPanel1.add(lTalla4);
        lTalla4.setBounds(50, 170, 110, 20);
        jPanel1.add(codV);
        codV.setBounds(30, 190, 140, 22);
        jPanel1.add(contra);
        contra.setBounds(30, 250, 140, 22);

        lTalla5.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla5.setText("Contraseña");
        jPanel1.add(lTalla5);
        lTalla5.setBounds(60, 230, 110, 20);
        jPanel1.add(nomU);
        nomU.setBounds(190, 190, 140, 22);

        lTalla6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla6.setText("Nombre Usuario");
        jPanel1.add(lTalla6);
        lTalla6.setBounds(210, 170, 110, 20);

        lTalla7.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla7.setText("Color");
        jPanel1.add(lTalla7);
        lTalla7.setBounds(240, 230, 110, 20);
        jPanel1.add(color);
        color.setBounds(190, 250, 140, 22);

        lTalla8.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla8.setText("Marca");
        jPanel1.add(lTalla8);
        lTalla8.setBounds(80, 300, 110, 20);
        jPanel1.add(marca);
        marca.setBounds(30, 320, 140, 22);

        lTalla9.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla9.setText("Modelo");
        jPanel1.add(lTalla9);
        lTalla9.setBounds(230, 300, 110, 20);
        jPanel1.add(modelo);
        modelo.setBounds(190, 320, 140, 22);

        lTalla10.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla10.setText("Talla");
        jPanel1.add(lTalla10);
        lTalla10.setBounds(80, 360, 110, 20);
        jPanel1.add(talla);
        talla.setBounds(30, 380, 140, 22);

        lTalla11.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla11.setText("Cantidad Pagar");
        jPanel1.add(lTalla11);
        lTalla11.setBounds(50, 420, 110, 20);
        jPanel1.add(cantPagar);
        cantPagar.setBounds(30, 440, 140, 22);

        btnComprar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnComprar.setText("Comprar");
        btnComprar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });
        jPanel1.add(btnComprar);
        btnComprar.setBounds(800, 490, 100, 23);

        lTalla12.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla12.setText("Cantidad");
        jPanel1.add(lTalla12);
        lTalla12.setBounds(230, 360, 110, 20);
        jPanel1.add(cantidad);
        cantidad.setBounds(190, 380, 140, 22);

        lTalla13.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla13.setText("   Total Pagar");
        jPanel1.add(lTalla13);
        lTalla13.setBounds(210, 420, 110, 20);
        jPanel1.add(totalPagar);
        totalPagar.setBounds(190, 440, 140, 22);

        MostrarDatos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        MostrarDatos.setText("Mostrar Datos");
        MostrarDatos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        MostrarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MostrarDatosActionPerformed(evt);
            }
        });
        jPanel1.add(MostrarDatos);
        MostrarDatos.setBounds(680, 490, 110, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoG2.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1090, 530);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1083, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
       //String SQLU="UPDATE carrocompras SET codigoVenta='"+codV.getText()+"',nomUser='"+nomU.getText()+"',contraseña='"+contra.getText()+"',color='"+color.getText()+"',marca='"+marca.getText()+"',modelo='"+modelo.getText()+"',talla='"+talla.getText()+"',cantidad='"+cantidad.getText()+"',cantidadPagar='"+cantPagar.getText()+"',totalPagar='"+totalPagar.getText()+"' where codigoVenta='"+codigoVenta.getText()+"'and marca='"+bmarca.getText()+"'and modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"'and color='"+bcolor.getText()+"' ";
       java.sql.Statement ss; 
       /*En la sentencia se puse "insert" por que vamos a insertar "into(en)" la tabla de "compras" 
         entre parentesis se pusieron los nombres de la base de datos para insertarlos en esos especificamente
         y despues se pone la palabra "values" con (?) que representan la cantidad de datos
       */
       
       String SQL="insert into compras(codigoVenta,nomUser,contraseña,color,marca,modelo,talla,cantidad,cantidadPagar,totalPagar) values (?,?,?,?,?,?,?,?,?,?)";
        
        try {
            java.sql.PreparedStatement ps=con.prepareStatement(SQL);
            
            ps.setString(1, codV.getText());
            ps.setString(2,nomU.getText());
            ps.setString(3,contra.getText());
            ps.setString(4,color.getText());
            ps.setString(5,marca.getText());
            ps.setString(6,modelo.getText());
            ps.setFloat(7, Float.parseFloat(talla.getText()));
            ps.setInt(8, Integer.parseInt(cantidad.getText()));
            ps.setFloat(9, Float.parseFloat(cantPagar.getText()));
            ps.setFloat(10, Float.parseFloat(totalPagar.getText()));
            ps.execute();
            JOptionPane.showMessageDialog(null, "COMPRA EXIOSA");
            
       
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
        }
        
        String cod = codigoVenta.getText();
        String marcas = marca.getText();
        String model = modelo.getText();
        String tallaa = talla.getText();
        String colors = color.getText();
         try {
            java.sql.Statement s = con.createStatement(); 
            /*
              "DELETE" para eliminar ciertos datos "FROM(De) nuestra tabla "carrocompras"
              esto porque al ya comprar un articulo del carrito ya no deberá existir en nuestra
              tabla de "carrocompras" debido a que ya no esta "pendiente" de comprar
            */
                    
            String sql="DELETE FROM carrocompras  WHERE  codigoVenta='"+cod+"'and modelo='"+model+"'and talla='"+tallaa+"'and marca='"+marcas+"'and color='"+colors+"' ";
            s.executeUpdate(sql);
            mostrarDatos("");
       
        } catch (SQLException ex) {
            Logger.getLogger(EliminarProductos.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERROR NO SE PUDO ELIMINAR");
        }
  
         //Limpiamos los Text Field
        codigoVenta.setText(null);
        codV.setText(null);
        nomU.setText(null);
        contra.setText(null);
        color.setText(null);
        marca.setText(null);
        cantidad.setText(null);
        modelo.setText(null);
        talla.setText(null);
        cantPagar.setText(null);
        totalPagar.setText(null);
    }//GEN-LAST:event_btnComprarActionPerformed

    private void tabCarritoAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabCarritoAMouseClicked
        modificar();
    }//GEN-LAST:event_tabCarritoAMouseClicked

    private void MostrarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MostrarDatosActionPerformed
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        String cod = codigoVenta.getText();
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from carrocompras WHERE  codigoVenta='"+cod+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                mod.addRow(reg);
            }
            tabCarritoA.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }//GEN-LAST:event_MostrarDatosActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ComprarDelCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ComprarDelCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ComprarDelCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ComprarDelCarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ComprarDelCarrito().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton MostrarDatos;
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField cantPagar;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField codV;
    private javax.swing.JTextField codigoVenta;
    private javax.swing.JTextField color;
    private javax.swing.JTextField contra;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lTalla10;
    private javax.swing.JLabel lTalla11;
    private javax.swing.JLabel lTalla12;
    private javax.swing.JLabel lTalla13;
    private javax.swing.JLabel lTalla4;
    private javax.swing.JLabel lTalla5;
    private javax.swing.JLabel lTalla6;
    private javax.swing.JLabel lTalla7;
    private javax.swing.JLabel lTalla8;
    private javax.swing.JLabel lTalla9;
    private javax.swing.JTextField marca;
    private javax.swing.JTextField modelo;
    private javax.swing.JTextField nomU;
    private javax.swing.JTable tabCarritoA;
    private javax.swing.JTextField talla;
    private javax.swing.JTextField totalPagar;
    // End of variables declaration//GEN-END:variables
}
