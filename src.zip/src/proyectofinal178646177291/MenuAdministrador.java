package proyectofinal178646177291;


/*
   FRAME que contiene las opciones que tiene dispobibles los Administradores,  desde Consultas,
   Elimanr, Modificar.
*/

import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
public class MenuAdministrador extends javax.swing.JFrame {

    static String nombreA;
    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public MenuAdministrador() {
        initComponents();
        nuevoIcono();
        setLocationRelativeTo(null);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        cProd = new javax.swing.JMenuItem();
        cAdmin = new javax.swing.JMenuItem();
        cUser = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        rProd = new javax.swing.JMenuItem();
        rAdmin = new javax.swing.JMenuItem();
        rUser = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        mProd = new javax.swing.JMenuItem();
        mAdmin = new javax.swing.JMenuItem();
        mUser = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        elimP = new javax.swing.JMenuItem();
        elimAdmin = new javax.swing.JMenuItem();
        elimU = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        opcConsultarV = new javax.swing.JMenuItem();
        opcModSistemaV = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        opcCC = new javax.swing.JMenuItem();
        opcMC = new javax.swing.JMenuItem();
        opcEC = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 50)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("BIENVENIDO");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(170, 150, 270, 110);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoGrietas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 610, 430);

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel7.setText("jLabel5");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(120, 150, 70, 20);

        jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel12.setText("jLabel5");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(310, 370, 190, 20);

        jMenu1.setText("Consultas");

        cProd.setText("Productos");
        cProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cProdActionPerformed(evt);
            }
        });
        jMenu1.add(cProd);

        cAdmin.setText("Administradores");
        cAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAdminActionPerformed(evt);
            }
        });
        jMenu1.add(cAdmin);

        cUser.setText("Usuarios");
        cUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cUserActionPerformed(evt);
            }
        });
        jMenu1.add(cUser);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Registros");

        rProd.setText("Productos");
        rProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rProdActionPerformed(evt);
            }
        });
        jMenu3.add(rProd);

        rAdmin.setText("Administradores");
        rAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rAdminActionPerformed(evt);
            }
        });
        jMenu3.add(rAdmin);

        rUser.setText("Usuarios");
        rUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rUserActionPerformed(evt);
            }
        });
        jMenu3.add(rUser);

        jMenuBar1.add(jMenu3);

        jMenu6.setText("Modificaciones");

        mProd.setText("Productos");
        mProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mProdActionPerformed(evt);
            }
        });
        jMenu6.add(mProd);

        mAdmin.setText("Administradores");
        mAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mAdminActionPerformed(evt);
            }
        });
        jMenu6.add(mAdmin);

        mUser.setText("Usuarios");
        mUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mUserActionPerformed(evt);
            }
        });
        jMenu6.add(mUser);

        jMenuBar1.add(jMenu6);

        jMenu7.setText("Eliminar");

        elimP.setText("Productos");
        elimP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                elimPActionPerformed(evt);
            }
        });
        jMenu7.add(elimP);

        elimAdmin.setText("Administradores");
        elimAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                elimAdminActionPerformed(evt);
            }
        });
        jMenu7.add(elimAdmin);

        elimU.setText("Usuarios");
        elimU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                elimUActionPerformed(evt);
            }
        });
        jMenu7.add(elimU);

        jMenuBar1.add(jMenu7);

        jMenu8.setText("Sistema Ventas");

        opcConsultarV.setText("Consultar Ventas");
        opcConsultarV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcConsultarVMouseClicked(evt);
            }
        });
        opcConsultarV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcConsultarVActionPerformed(evt);
            }
        });
        jMenu8.add(opcConsultarV);

        opcModSistemaV.setText("Modificar Ventas");
        opcModSistemaV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcModSistemaVActionPerformed(evt);
            }
        });
        jMenu8.add(opcModSistemaV);

        jMenuItem2.setText("Eliminar Ventas");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu8.add(jMenuItem2);

        jMenuBar1.add(jMenu8);

        jMenu9.setText("Carro Compras");

        opcCC.setText("Consultar Carro");
        opcCC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCCMouseClicked(evt);
            }
        });
        opcCC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCCActionPerformed(evt);
            }
        });
        jMenu9.add(opcCC);

        opcMC.setText("Modificar Carro");
        opcMC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcMCActionPerformed(evt);
            }
        });
        jMenu9.add(opcMC);

        opcEC.setText("Eliminar Carro");
        opcEC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcECActionPerformed(evt);
            }
        });
        jMenu9.add(opcEC);

        jMenuBar1.add(jMenu9);

        jMenu5.setText("Más Opciones");

        jMenuItem1.setText("Cerrar Sesion");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem1);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 601, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAdminActionPerformed
        ConsultaAdministradores menu = new ConsultaAdministradores();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_cAdminActionPerformed

    private void cProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cProdActionPerformed
        ConsultaProductos menu = new ConsultaProductos();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_cProdActionPerformed

    private void cUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cUserActionPerformed
        ConsultaUsuarios menu = new ConsultaUsuarios();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_cUserActionPerformed

    private void rProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rProdActionPerformed
        RegistroProducto menu = new RegistroProducto();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_rProdActionPerformed

    private void rAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rAdminActionPerformed
        RegistroAdministradores menu = new RegistroAdministradores();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_rAdminActionPerformed

    private void rUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rUserActionPerformed
        RegistroUsuarioAdmi menu = new RegistroUsuarioAdmi();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_rUserActionPerformed

    private void mProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mProdActionPerformed
        ModificarProductos menu = new ModificarProductos();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_mProdActionPerformed

    private void mAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mAdminActionPerformed
        ModificarAdmi menu = new ModificarAdmi();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_mAdminActionPerformed

    private void mUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mUserActionPerformed
        ModificarUser menu = new ModificarUser();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_mUserActionPerformed

    private void elimPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_elimPActionPerformed
        EliminarProductos menu= new EliminarProductos();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_elimPActionPerformed

    private void elimAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_elimAdminActionPerformed
        EliminarAdmis menu= new EliminarAdmis();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_elimAdminActionPerformed

    private void elimUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_elimUActionPerformed
        EliminarUsuarios menu= new EliminarUsuarios();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_elimUActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        JOptionPane.showMessageDialog(null, "SE CERRÓ SESION CORRECTAMENTE");

    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void opcConsultarVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcConsultarVActionPerformed
        ConsultaSistemaVentas menu = new ConsultaSistemaVentas();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();      
    }//GEN-LAST:event_opcConsultarVActionPerformed

    private void opcConsultarVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcConsultarVMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_opcConsultarVMouseClicked

    private void opcModSistemaVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcModSistemaVActionPerformed
        ModificarSistemaVentas menu = new ModificarSistemaVentas();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();     
    }//GEN-LAST:event_opcModSistemaVActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        EliminarSistemaVentas menu = new EliminarSistemaVentas();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();  
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void opcCCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCCMouseClicked
       
    }//GEN-LAST:event_opcCCMouseClicked

    private void opcCCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCCActionPerformed
        ConsultaCarritoAdmi menu = new ConsultaCarritoAdmi();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose(); 
    }//GEN-LAST:event_opcCCActionPerformed

    private void opcMCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcMCActionPerformed
        ModificarCarritoAdmi menu = new ModificarCarritoAdmi();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();  
    }//GEN-LAST:event_opcMCActionPerformed

    private void opcECActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcECActionPerformed
        EliminarCarritoAdmi menu = new EliminarCarritoAdmi();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose(); 
    }//GEN-LAST:event_opcECActionPerformed


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuAdministrador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem cAdmin;
    private javax.swing.JMenuItem cProd;
    private javax.swing.JMenuItem cUser;
    private javax.swing.JMenuItem elimAdmin;
    private javax.swing.JMenuItem elimP;
    private javax.swing.JMenuItem elimU;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem mAdmin;
    private javax.swing.JMenuItem mProd;
    private javax.swing.JMenuItem mUser;
    private javax.swing.JMenuItem opcCC;
    private javax.swing.JMenuItem opcConsultarV;
    private javax.swing.JMenuItem opcEC;
    private javax.swing.JMenuItem opcMC;
    private javax.swing.JMenuItem opcModSistemaV;
    private javax.swing.JMenuItem rAdmin;
    private javax.swing.JMenuItem rProd;
    private javax.swing.JMenuItem rUser;
    // End of variables declaration//GEN-END:variables
}
