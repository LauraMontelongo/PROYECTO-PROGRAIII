package proyectofinal178646177291;

/*
   FRAME que hace la consulta de las Compras que a hecho el Usuario
   a partir del Código Único
*/

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.sql.*;
import javax.swing.JOptionPane;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import Conexiones.conectar.ConexionSQL;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import java.io.IOException;
import java.time.LocalDateTime;
import javax.swing.ImageIcon;
public class MostrarComprasDelUsuario extends javax.swing.JFrame {


     ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public MostrarComprasDelUsuario() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
       
    }

 public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        claveUnic = new javax.swing.JTextField();
        btnMostrarDatos = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCompras = new javax.swing.JTable();
        lColor3 = new javax.swing.JLabel();
        btnPDf = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("COMPRAS REALIZADAS");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(430, 10, 220, 50);

        claveUnic.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        claveUnic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                claveUnicActionPerformed(evt);
            }
        });
        jPanel1.add(claveUnic);
        claveUnic.setBounds(520, 100, 170, 22);

        btnMostrarDatos.setBackground(new java.awt.Color(204, 204, 204));
        btnMostrarDatos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnMostrarDatos.setText("Mostrar Compras");
        btnMostrarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDatosActionPerformed(evt);
            }
        });
        jPanel1.add(btnMostrarDatos);
        btnMostrarDatos.setBounds(720, 90, 170, 30);

        btnVolver.setBackground(new java.awt.Color(204, 204, 204));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(30, 440, 110, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoMorado.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(400, 20, 260, 30);

        tabCompras.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido Materno", "Apellido Paterno", "Puesto", "Edad", "Nombre Usuario", "Contraseña"
            }
        ));
        tabCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabComprasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabCompras);
        if (tabCompras.getColumnModel().getColumnCount() > 0) {
            tabCompras.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabCompras.getColumnModel().getColumn(3).setPreferredWidth(12);
            tabCompras.getColumnModel().getColumn(4).setPreferredWidth(9);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(90, 170, 970, 220);

        lColor3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor3.setText("*Código Venta Único:");
        jPanel1.add(lColor3);
        lColor3.setBounds(370, 100, 190, 20);

        btnPDf.setBackground(new java.awt.Color(204, 204, 204));
        btnPDf.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPDf.setText("PDF");
        btnPDf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDfActionPerformed(evt);
            }
        });
        jPanel1.add(btnPDf);
        btnPDf.setBounds(900, 90, 170, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietasMorado.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1260, 490);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1143, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Cantidad","Cantidad Pagar","Total Pagar"};
        String[] reg=new String[9];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from compras WHERE codigoVenta='"+claveUnic.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("cantidad");
                reg[7]=rs.getString("cantidadPagar");
                reg[8]=rs.getString("totalPagar");
                
                mod.addRow(reg);
            }
            tabCompras.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
 

    private void btnMostrarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDatosActionPerformed
        mostrarDatos("");
    }//GEN-LAST:event_btnMostrarDatosActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabComprasMouseClicked
       
    }//GEN-LAST:event_tabComprasMouseClicked

    private void claveUnicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_claveUnicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_claveUnicActionPerformed

    private void btnPDfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDfActionPerformed
        Document documento1 = new Document();
       
        try {
            String ruta = System.getProperty("user.home");
            PdfWriter.getInstance(documento1, new FileOutputStream(ruta + "/Downloads/Reporte_Compras.pdf"));
            documento1.open();
            
           
            
            //TITULO DEL PDF
            Font font = new Font(Font.FontFamily.TIMES_ROMAN, 24, Font.BOLD,BaseColor.ORANGE);
            Paragraph title = new Paragraph("REPORTE DE SUS COMPRAS", font);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(title);
            
            //AGREGAMOS UN ESPACIO
            Paragraph espacio = new Paragraph(" ", font);
            documento1.add(espacio);
            
            Font fontExtra = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL,BaseColor.BLACK);
            Paragraph informacion = new Paragraph("--------------------------------------------------------------------------------", fontExtra);
            informacion.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(informacion);
            Paragraph t1 = new Paragraph("Correo: tibiosShoes@gmaol.com", fontExtra);
            t1.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(t1);
            Paragraph t2 = new Paragraph("Facebook: Tibios Shoes Family", fontExtra);
            t2.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(t2);
            informacion.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(informacion);
            Paragraph t3 = new Paragraph("INFORMACIÓN DE LA COMPRA", fontExtra);
            
            Paragraph tiempo= new Paragraph("DETALLES IMPRESIÓN", fontExtra);
            tiempo.setAlignment(Paragraph.ALIGN_CENTER);
            int gminutos;
            int ghora;
            int gdia;
            int gmes;
            int gaño;
            
            gdia = LocalDateTime.now().getDayOfMonth();
            gmes = LocalDateTime.now().getMonthValue();
            gaño = LocalDateTime.now().getYear();
            ghora = LocalDateTime.now().getHour();
            gminutos = LocalDateTime.now().getMinute();
            tiempo.add("\nFecha: "+gdia+"/"+gmes+"/"+gaño + "  Hora: " +ghora+" horas con "+gminutos + " minutos\n");
            documento1.add(tiempo);
            documento1.add(informacion);
            t3.setAlignment(Paragraph.ALIGN_CENTER);
            documento1.add(t3);
            documento1.add(informacion);
            documento1.add(espacio);
            
            Font fontTabla = new Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL,BaseColor.BLACK);
            PdfPTable tabla = new PdfPTable(10);
            tabla.addCell("Codigo Venta" );
            tabla.addCell("Nombre Usuario");
            tabla.addCell("Contraseña");
            tabla.addCell("Color");
            tabla.addCell("Marca");
            tabla.addCell("Modelo");
            tabla.addCell("Talla");
            tabla.addCell("Cantidad");
            tabla.addCell("Cantidad Pagar");
            tabla.addCell("Total Pagar");
            String cVenta = claveUnic.getText();
            try {
               
                String SQL="select * from compras WHERE codigoVenta='"+cVenta+"'";
        
        
                java.sql.Statement s = con.createStatement(); 
                java.sql.ResultSet rs = s.executeQuery (SQL);
                
                
                if(rs.next()){
                                       
                    do {                       
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                        tabla.addCell(rs.getString(5));
                        tabla.addCell(rs.getString(6));
                        tabla.addCell(rs.getString(7));
                        tabla.addCell(rs.getString(8));
                        tabla.addCell(rs.getString(9));
                        tabla.addCell(rs.getString(10));
                        
                    } while (rs.next());
                    documento1.add(tabla);                    
                }
                
            } catch (DocumentException | SQLException e) {
            }
            
            documento1.close();
            JOptionPane.showMessageDialog(null, "PDF Exitoso!.");
        } catch (DocumentException | HeadlessException | FileNotFoundException e) {
        } catch (IOException ex) {
             Logger.getLogger(MostrarComprasDelUsuario.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_btnPDfActionPerformed
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MostrarComprasDelUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MostrarComprasDelUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MostrarComprasDelUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MostrarComprasDelUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MostrarComprasDelUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrarDatos;
    private javax.swing.JButton btnPDf;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField claveUnic;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor3;
    private javax.swing.JTable tabCompras;
    // End of variables declaration//GEN-END:variables
}
