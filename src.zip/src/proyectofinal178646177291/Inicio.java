package proyectofinal178646177291;


/*
   FRAME que contiene el ACCESSO a la opción de "Administrador" y "Usuario" según sea el caso
*/

import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class Inicio extends javax.swing.JFrame {

    static String nombreA;
    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public Inicio() {
        initComponents();
        nuevoIcono();
        setLocationRelativeTo(null);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nameU = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        ingresar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnRegisUser = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        passwordUser = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 80)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tibios Shoes");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(50, 0, 460, 110);

        nameU.setBackground(new java.awt.Color(255, 153, 153));
        nameU.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nameU.setForeground(new java.awt.Color(255, 255, 255));
        nameU.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        nameU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameUActionPerformed(evt);
            }
        });
        jPanel1.add(nameU);
        nameU.setBounds(210, 150, 140, 22);

        jLabel3.setFont(new java.awt.Font("Cambria", 1, 16)); // NOI18N
        jLabel3.setText("User: ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(140, 150, 70, 20);

        ingresar.setBackground(new java.awt.Color(0, 0, 0));
        ingresar.setFont(new java.awt.Font("Cambria", 1, 16)); // NOI18N
        ingresar.setText("Ingresar");
        ingresar.setAutoscrolls(true);
        ingresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ingresar.setContentAreaFilled(false);
        ingresar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ingresar.setFocusPainted(false);
        ingresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresarActionPerformed(evt);
            }
        });
        jPanel1.add(ingresar);
        ingresar.setBounds(210, 370, 130, 22);

        jLabel9.setFont(new java.awt.Font("Cambria", 1, 16)); // NOI18N
        jLabel9.setText("Password:");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(100, 210, 76, 20);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(120, 150, 70, 20);

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel8.setText("jLabel5");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(90, 210, 100, 20);

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel10.setText("jLabel5");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(210, 370, 130, 20);

        btnRegisUser.setBackground(new java.awt.Color(0, 0, 0));
        btnRegisUser.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        btnRegisUser.setText("Registrarme: Cliente");
        btnRegisUser.setAutoscrolls(true);
        btnRegisUser.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegisUser.setContentAreaFilled(false);
        btnRegisUser.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnRegisUser.setFocusPainted(false);
        btnRegisUser.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRegisUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisUserActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegisUser);
        btnRegisUser.setBounds(170, 310, 190, 22);

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel11.setText("jLabel5");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(170, 310, 190, 20);

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel7.setText("jLabel5");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(120, 150, 70, 20);

        passwordUser.setBackground(new java.awt.Color(255, 153, 153));
        passwordUser.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        passwordUser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                passwordUserKeyPressed(evt);
            }
        });
        jPanel1.add(passwordUser);
        passwordUser.setBounds(210, 210, 140, 20);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tenis.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 550, 430);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 429, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void ingresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingresarActionPerformed

        int resultado=0;
        String pass=String.valueOf(passwordUser.getPassword());
        String user=nameU.getText();
        String SQL="select * from administradores where nombre_usuario='"+user+"' and contraseña='"+pass+"' ";
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            if(rs.next()){
                resultado=1;
                if(resultado==1){
                    
                    MenuAdministrador mn=new MenuAdministrador();
                    mn.setVisible(true);
                    this.dispose();
                    JOptionPane.showMessageDialog(null, "BIENVENIDO ADMINISTRADOR :)");
                }
            }else{
              
                String SQ="select * from usuarios where nombre_user='"+user+"' and contraseñaU='"+pass+"' ";
                java.sql.Statement st = con.createStatement(); 
                java.sql.ResultSet rss = st.executeQuery (SQ);
                if(rss.next()){
                    resultado=1;
                    if(resultado==1){
                    
                    CatalogoUsuarioP ms=new CatalogoUsuarioP();
                    ms.setVisible(true);
                    this.dispose();
                    JOptionPane.showMessageDialog(null, "BIENVENIDO :)");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Error al accesar");
                    passwordUser.setText(null);//LIMPIAMOS
                    nameU.setText(null);
                }
                
                
                
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error"+e.getMessage());
        }
        
    }//GEN-LAST:event_ingresarActionPerformed

    private void nameUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameUActionPerformed

    private void btnRegisUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisUserActionPerformed
        RegistroUsuario menu = new RegistroUsuario();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_btnRegisUserActionPerformed

    private void passwordUserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordUserKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordUserKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegisUser;
    private javax.swing.JButton ingresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    public javax.swing.JTextField nameU;
    public javax.swing.JPasswordField passwordUser;
    // End of variables declaration//GEN-END:variables
}
