package proyectofinal178646177291;


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class EliminarCarritoUser extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public EliminarCarritoUser() {
        initComponents();
        nuevoIcono();
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
  
     public void modificar(){
        int fila=tabCarritoA.getSelectedRow();
        if(fila>=0){
            
            codigoVenta.setText(tabCarritoA.getValueAt(fila, 0).toString());
           
            bcolor.setText(tabCarritoA.getValueAt(fila, 3).toString());
            
            bmarca.setText(tabCarritoA.getValueAt(fila, 4).toString());
           
            bmodelo.setText(tabCarritoA.getValueAt(fila, 5).toString());
           
            btalla.setText(tabCarritoA.getValueAt(fila, 6).toString());
            
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCarritoA = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        lColor = new javax.swing.JLabel();
        codigoVenta = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        lColor1 = new javax.swing.JLabel();
        bmarca = new javax.swing.JTextField();
        lColor2 = new javax.swing.JLabel();
        bmodelo = new javax.swing.JTextField();
        btalla = new javax.swing.JTextField();
        lColor3 = new javax.swing.JLabel();
        bcolor = new javax.swing.JTextField();
        lColor4 = new javax.swing.JLabel();
        btnEliminar1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("ELIMINAR CARRITO");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(530, 20, 240, 40);

        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(930, 490, 100, 23);

        tabCarritoA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Marca", "Modelo", "Color", "Talla", "Precio", "Cantidad"
            }
        ));
        tabCarritoA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabCarritoAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabCarritoA);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 160, 1050, 290);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(480, 20, 280, 40);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setText("*Código Venta:");
        jPanel1.add(lColor);
        lColor.setBounds(50, 100, 190, 20);

        codigoVenta.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.add(codigoVenta);
        codigoVenta.setBounds(150, 100, 190, 22);

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar);
        btnEliminar.setBounds(790, 490, 100, 23);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setText("*Marca:");
        jPanel1.add(lColor1);
        lColor1.setBounds(350, 100, 60, 20);

        bmarca.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.add(bmarca);
        bmarca.setBounds(410, 100, 120, 22);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setText("*Modelo:");
        jPanel1.add(lColor2);
        lColor2.setBounds(540, 100, 60, 20);

        bmodelo.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.add(bmodelo);
        bmodelo.setBounds(600, 100, 120, 22);

        btalla.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.add(btalla);
        btalla.setBounds(800, 100, 70, 22);

        lColor3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor3.setText("*Talla:");
        jPanel1.add(lColor3);
        lColor3.setBounds(740, 100, 60, 20);

        bcolor.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.add(bcolor);
        bcolor.setBounds(950, 100, 70, 22);

        lColor4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor4.setText("*Color:");
        jPanel1.add(lColor4);
        lColor4.setBounds(890, 100, 60, 20);

        btnEliminar1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEliminar1.setText("Mostrar Datos");
        btnEliminar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        btnEliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar1);
        btnEliminar1.setBounds(650, 490, 110, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FondoManchasColores.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1090, 530);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1083, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        
        java.sql.Statement ss; 
        String cVenta = codigoVenta.getText();
        String marca = bmarca.getText();
        String modelo = bmodelo.getText();
        String talla = btalla.getText();
        String color = bcolor.getText();
        try {
            ss = con.createStatement();
             String sql="DELETE FROM carrocompras WHERE  codigoVenta='"+cVenta+"'and marca='"+marca+"'and modelo='"+modelo+"'and talla='"+talla+"'and color='"+color+"' ";
             ss.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "ACTUZALIZADO");
       
        } catch (SQLException ex) {
            Logger.getLogger(ModificarAdmi.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        codigoVenta.setText(null);
        bcolor.setText(null);
        bmarca.setText(null);
        bmodelo.setText(null);
        btalla.setText(null);
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tabCarritoAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabCarritoAMouseClicked
        modificar();
    }//GEN-LAST:event_tabCarritoAMouseClicked

    private void btnEliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminar1ActionPerformed
         String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from carrocompras where codigoVenta='"+codigoVenta.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                mod.addRow(reg);
            }
            tabCarritoA.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }//GEN-LAST:event_btnEliminar1ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarCarritoUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarCarritoUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarCarritoUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarCarritoUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarCarritoUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bcolor;
    private javax.swing.JTextField bmarca;
    private javax.swing.JTextField bmodelo;
    private javax.swing.JTextField btalla;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEliminar1;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField codigoVenta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lColor3;
    private javax.swing.JLabel lColor4;
    private javax.swing.JTable tabCarritoA;
    // End of variables declaration//GEN-END:variables
}
