package proyectofinal178646177291;

/*
   FRAME hecho para que el usuario Pueda llevar a cabo la compra especifica en los productos
   Además puede Agregar al Carrito los productos que no quiera comprar en es momento
*/
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.jfree.chart.ChartPanel;


import Conexiones.conectar.ConexionSQL;
public class SistemaVentasC5 extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    private DefaultTableModel model;
    ArrayList<SistemaVentasC5.Producto> carrito = new ArrayList<>();
    public SistemaVentasC5() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos(" ");
    }
    
     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }

    public class Producto {
    private String codigoVenta;
    private String nombre;
    private String  contraseña;
    private String color;
    private String  marca;
    private String modelo;
    private float  talla;
    private int cantidad;
    private float  cantT;
    private float  totalT;
    
    public Producto(String codigoVenta,String nombre, String contraseña, String color, String marca, String modelo, float talla, int cantidad, float cantT, float totalT) {
        this.codigoVenta = codigoVenta;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.talla = talla;
        this.cantidad = cantidad;
        this.cantT = cantT;
        this.totalT = totalT;
    }

        public String getCodigoVenta() {
            return codigoVenta;
        }

        public String getNombre() {
            return nombre;
        }

        public String getContraseña() {
            return contraseña;
        }

        public String getColor() {
            return color;
        }

        public String getMarca() {
            return marca;
        }

        public String getModelo() {
            return modelo;
        }

        public float getTalla() {
            return talla;
        }

        public int getCantidad() {
            return cantidad;
        }

        public float getCantidadT() {
            cantT = 1649*cantidad;
            return cantT;
        }

        public float getTotalT() {
            totalT = cantT+94.5f;
            return totalT;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnComprar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabElimU = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        tfcodigoVenta = new javax.swing.JLabel();
        bcolor = new javax.swing.JTextField();
        tfcodigoVenta1 = new javax.swing.JLabel();
        codigoUnico = new javax.swing.JTextField();
        tfcodigoVenta2 = new javax.swing.JLabel();
        bmarca = new javax.swing.JTextField();
        tfcodigoVenta3 = new javax.swing.JLabel();
        bmodelo = new javax.swing.JTextField();
        tfcodigoVenta4 = new javax.swing.JLabel();
        bcantidad = new javax.swing.JTextField();
        tfcodigoVenta5 = new javax.swing.JLabel();
        bnombreUs = new javax.swing.JTextField();
        tfcodigoVenta6 = new javax.swing.JLabel();
        bcontra = new javax.swing.JTextField();
        tfcodigoVenta7 = new javax.swing.JLabel();
        btalla = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        btnCarrito = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcVerLosDemasModelos5 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("SISTEMA DE VENTAS");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(510, 10, 220, 50);

        btnComprar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnComprar.setText("COMPRAR");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });
        jPanel1.add(btnComprar);
        btnComprar.setBounds(860, 50, 130, 30);

        btnVolver.setBackground(new java.awt.Color(204, 204, 204));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(20, 420, 110, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(470, 20, 260, 30);

        tabElimU.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Codigo Venta", "Color", "Marca", "Modelo", "Cantidad", "Cantidad Pagar", "Total Pagar"
            }
        ));
        tabElimU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabElimUMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabElimU);
        if (tabElimU.getColumnModel().getColumnCount() > 0) {
            tabElimU.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabElimU.getColumnModel().getColumn(3).setPreferredWidth(9);
            tabElimU.getColumnModel().getColumn(4).setPreferredWidth(16);
            tabElimU.getColumnModel().getColumn(5).setPreferredWidth(12);
            tabElimU.getColumnModel().getColumn(6).setPreferredWidth(12);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(300, 270, 910, 210);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Comprar"));

        tfcodigoVenta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta.setText("Código Venta:");

        bcolor.setBackground(new java.awt.Color(233, 216, 249));
        bcolor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcolor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcolorActionPerformed(evt);
            }
        });

        tfcodigoVenta1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta1.setText("Color:");

        codigoUnico.setBackground(new java.awt.Color(233, 216, 249));
        codigoUnico.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        codigoUnico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigoUnicoActionPerformed(evt);
            }
        });

        tfcodigoVenta2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta2.setText("Marca:");

        bmarca.setBackground(new java.awt.Color(233, 216, 249));
        bmarca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bmarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmarcaActionPerformed(evt);
            }
        });

        tfcodigoVenta3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta3.setText("Modelo:");

        bmodelo.setBackground(new java.awt.Color(233, 216, 249));
        bmodelo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bmodelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodeloActionPerformed(evt);
            }
        });

        tfcodigoVenta4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta4.setText("Cantidad:");

        bcantidad.setBackground(new java.awt.Color(233, 216, 249));
        bcantidad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcantidadActionPerformed(evt);
            }
        });

        tfcodigoVenta5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta5.setText("Nombre Usuario:");

        bnombreUs.setBackground(new java.awt.Color(233, 216, 249));
        bnombreUs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bnombreUs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnombreUsActionPerformed(evt);
            }
        });

        tfcodigoVenta6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta6.setText("Contraseña");

        bcontra.setBackground(new java.awt.Color(233, 216, 249));
        bcontra.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcontra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcontraActionPerformed(evt);
            }
        });

        tfcodigoVenta7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta7.setText("Talla:");

        btalla.setBackground(new java.awt.Color(233, 216, 249));
        btalla.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btalla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btallaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tfcodigoVenta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(codigoUnico, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfcodigoVenta5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bnombreUs, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfcodigoVenta6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bcontra, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tfcodigoVenta1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bcolor, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(tfcodigoVenta2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(tfcodigoVenta3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bmodelo, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfcodigoVenta4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfcodigoVenta7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btalla, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta6)
                        .addComponent(bcontra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta)
                        .addComponent(codigoUnico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta5)
                        .addComponent(bnombreUs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta7)
                        .addComponent(btalla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta4)
                        .addComponent(bcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta3)
                        .addComponent(bmodelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta2)
                        .addComponent(bmarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta1)
                        .addComponent(bcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(310, 90, 810, 120);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Especificaciones"));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Tallas: ");

        jLabel3.setText("23");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Colores:");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/amarillo.png"))); // NOI18N

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/rosa.png"))); // NOI18N

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/rosaClaro.png"))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("Marca:");

        jLabel11.setText("Converse");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Modelo:");

        jLabel13.setText("Florals ChuckTaylor ");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Envio");

        jLabel15.setText("$1,649");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Precio:");

        jLabel17.setText("$94.5");

        jLabel18.setText("PX3K6");

        jLabel19.setText("E1F9A");

        jLabel20.setText("WP00T");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel11))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel16)
                                        .addComponent(jLabel14))
                                    .addGap(18, 18, 18)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel17)
                                        .addComponent(jLabel15))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addContainerGap())
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(20, 70, 270, 230);

        btnCarrito.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCarrito.setText("CARRITO");
        btnCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarritoActionPerformed(evt);
            }
        });
        jPanel1.add(btnCarrito);
        btnCarrito.setBounds(1020, 50, 130, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietasMorado.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1220, 490);

        opcVerLosDemasModelos5.setText("Ver los Modelos");
        opcVerLosDemasModelos5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcVerLosDemasModelos5MouseClicked(evt);
            }
        });
        jMenuBar1.add(opcVerLosDemasModelos5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1217, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void mostrarDatos(String Nombre){
          //MOSTRAR DATOS
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from compras WHERE codigoVenta='"+codigoUnico.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
               reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                
                mod.addRow(reg);
            }
            tabElimU.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void mostrarDatos(){
         //MOSTRAR DATOS
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from compras WHERE codigoVenta='"+codigoUnico.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                
                mod.addRow(reg);
            }
            tabElimU.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        java.sql.Statement ss; 
        //String SQL = "SELECT * FROM productos  WHERE modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"'and color='"+bcolor.getText()+"'and marca='"+bmarca.getText()+"'";
        String SQL = "SELECT * FROM productos  WHERE modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"'and color='"+bcolor.getText()+"'and marca='"+bmarca.getText()+"'and cantidad>'"+0+"'";
        
         Excepciones x = new Excepciones();
    
        String codigVenta = codigoUnico.getText();        
        try{
            
            x.Largo(codigVenta, codigoUnico);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el Codigo de Venta, Limite de caracteres superado"+e);
        }
        
        String nomb = bnombreUs.getText();                                
        String contra = bcontra.getText();
                
        String colo = bcolor.getText();
        try{
            
            x.noMinusculas(colo, bcolor);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el color, no ingreses letras minusculas o caracteres"+e);
            
        }
        
        String mar = bmarca.getText();
        try{
            
            x.noNumeros(mar, bmarca);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en la marca, no ingreses letras numeros o caracteres"+e);
            
        }
        
        String mod = bmodelo.getText();
        try{
            
            x.noNumeros(mod, bmodelo);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el modelo, no ingreses letras numeros o caracteres"+e);
            
        }

        float tal=0;        
        try{
            
           tal = Float.parseFloat(btalla.getText());
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingresa solo numeros"+e);
        }
        
        int canti= 0;
        try{
            
            canti = Integer.parseInt(bcantidad.getText());
            
        }catch(NumberFormatException e){

            JOptionPane.showMessageDialog(null, "Error: Ingresa solo numeros en la Cantidad"+e);

        }
        try {
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            if (rs.next()) {
              SQL="insert into compras(codigoVenta,nomUser,contraseña,color,marca,modelo,talla,cantidad,cantidadPagar,totalPagar) values (?,?,?,?,?,?,?,?,?,?)";
              try{
                Float numP = 1649*Float.parseFloat(bcantidad.getText()); 
                Float totalP = numP + 94.5f; 
                java.sql.PreparedStatement ps=con.prepareStatement(SQL);
                ps.setString(1, codigoUnico.getText());
                ps.setString(2, bnombreUs.getText());
                ps.setString(3, bcontra.getText());
                ps.setString(4, bcolor.getText());
                ps.setString(5,bmarca.getText());
                ps.setString(6,bmodelo.getText());
                ps.setString(7,btalla.getText());
                ps.setFloat(8, Integer.parseInt(bcantidad.getText()));
                ps.setFloat(9, numP);          
                ps.setFloat(10, totalP);  
           
                ps.execute();
            
                JOptionPane.showMessageDialog(null, "Registro existoso");
             }catch(Exception e){
                 JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
             }
        
       
            //AQUI MODIFICAMOS LA CANTIDAD DE PRODUCTO QUE HAY
            String SQLU="UPDATE productos SET cantidad = cantidad-'"+bcantidad.getText()+"' WHERE modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"' ";
            //marca='"+marca.getText()
             try {
                ss = con.createStatement();
                ss.executeUpdate(SQLU);
                JOptionPane.showMessageDialog(null, "ACTUZALIZADO");


             } catch (SQLException ex) {
                Logger.getLogger(ModificarProductos.class.getName()).log(Level.SEVERE, null, ex);
             }
    
                //SE MUESTRAN LOS DATOS
                 mostrarDatos();
                 codigoUnico.setText(null);
                 bnombreUs.setText(null);
                 bcontra.setText(null);
                 bcolor.setText(null);
                 bmarca.setText(null);
                 bmodelo.setText(null);
                 btalla.setText(null);
                 bcantidad.setText(null);
             
            } else {
                JOptionPane.showMessageDialog(null, "ESTE PRODUCTO NO ESTA DISPONIBLE","Información",JOptionPane.INFORMATION_MESSAGE);
                codigoUnico.setText(null);
                 bnombreUs.setText(null);
                 bcontra.setText(null);
                 bcolor.setText(null);
                 bmarca.setText(null);
                 bmodelo.setText(null);
                 btalla.setText(null);
                 bcantidad.setText(null);
            }
      
        
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        

    }//GEN-LAST:event_btnComprarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoConverse menu = new CatalogoConverse();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabElimUMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabElimUMouseClicked

    }//GEN-LAST:event_tabElimUMouseClicked

    private void bcolorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcolorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcolorActionPerformed

    private void codigoUnicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigoUnicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoUnicoActionPerformed

    private void bmarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmarcaActionPerformed

    private void bmodeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmodeloActionPerformed

    private void bcantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcantidadActionPerformed

    private void bnombreUsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnombreUsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bnombreUsActionPerformed

    private void bcontraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcontraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcontraActionPerformed

    private void btallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btallaActionPerformed

    private void btnCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarritoActionPerformed

        model = new DefaultTableModel();
        model.addColumn("Codigo Venta");
        model.addColumn("Nombre Usuario");
        model.addColumn("Contraseña");
        model.addColumn("Color");
        model.addColumn("Marca");
        model.addColumn("Modelo");
        model.addColumn("Talla");
        model.addColumn("Cantidad");
        model.addColumn("Cantidad Pagar");
        model.addColumn("Total");

        Float cantT = 1649*Float.parseFloat(bcantidad.getText());
        Float totalT = cantT + 34.5f;
        // Agregar datos

        model.addRow(new Object[]{codigoUnico.getText(), bnombreUs.getText(), bcontra.getText(),bcolor.getText(),
            bmarca.getText(),bmodelo.getText(),btalla.getText(),bcantidad.getText(),cantT,totalT});

     Excepciones x = new Excepciones();
    
        String codigVenta = codigoUnico.getText();        
        try{
            
            x.Largo(codigVenta, codigoUnico);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el Codigo de Venta, Limite de caracteres superado"+e);
        }
        
        String nomb = bnombreUs.getText();                                
        String contra = bcontra.getText();
                
        String colo = bcolor.getText();
        try{
            
            x.noMinusculas(colo, bcolor);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el color, no ingreses letras minusculas o caracteres"+e);
            
        }
        
        String mar = bmarca.getText();
        try{
            
            x.noNumeros(mar, bmarca);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en la marca, no ingreses letras numeros o caracteres"+e);
            
        }
        
        String mod = bmodelo.getText();
        try{
            
            x.noNumeros(mod, bmodelo);
            
        } catch(Exception e){
            
            JOptionPane.showMessageDialog(null, "Error en el modelo, no ingreses letras numeros o caracteres"+e);
            
        }

        float tal=0;        
        try{
            
           tal = Float.parseFloat(btalla.getText());
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingresa solo numeros"+e);
        }
        
        int canti= 0;
        try{
            
            canti = Integer.parseInt(bcantidad.getText());
            
        }catch(NumberFormatException e){

            JOptionPane.showMessageDialog(null, "Error: Ingresa solo numeros en la Cantidad"+e);

        }
        
    //PARA AGREGAR OTRO
    String codigoVenta = codigoUnico.getText();
    String nombre = bnombreUs.getText();
    String contraseña = bcontra.getText();
    String color = bcolor.getText();
    String marca = bmarca.getText();
    String modelo = bmodelo.getText();
    float talla = Float.parseFloat(btalla.getText());
    int cantidad = Integer.parseInt(bcantidad.getText());

    // Agregar el producto al carrito
    Producto producto = new Producto(codigoVenta,nombre,contraseña,color,marca,modelo,talla,cantidad,cantT,totalT);
    carrito.add(producto);

    //METEMOS A LA BASE DE DATOS
    java.sql.Statement ss;
   String SQL = "SELECT * FROM productos  WHERE modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"'and color='"+bcolor.getText()+"'and marca='"+bmarca.getText()+"'";
    try {
        java.sql.Statement s = con.createStatement();
        java.sql.ResultSet rs = s.executeQuery (SQL);
        if (rs.next()) {
            SQL="insert into carrocompras(codigoVenta,nomUser,contraseña,color,marca,modelo,talla,cantidad,cantidadPagar,totalPagar) values (?,?,?,?,?,?,?,?,?,?)";
            try{
                Float numP = 1649*Float.parseFloat(bcantidad.getText());
                Float totalP = numP + 94.5f;
                java.sql.PreparedStatement ps=con.prepareStatement(SQL);
                ps.setString(1, codigoUnico.getText());
                ps.setString(2, bnombreUs.getText());
                ps.setString(3, bcontra.getText());
                ps.setString(4, bcolor.getText());
                ps.setString(5,bmarca.getText());
                ps.setString(6,bmodelo.getText());
                ps.setString(7,btalla.getText());
                ps.setFloat(8, Integer.parseInt(bcantidad.getText()));
                ps.setFloat(9, numP);
                ps.setFloat(10, totalP);

                ps.execute();

                JOptionPane.showMessageDialog(null, "Registro existoso");
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
            }

            //SE MUESTRAN LOS DATOS
            mostrarDatos();
            codigoUnico.setText(null);
            bnombreUs.setText(null);
            bcontra.setText(null);
            bcolor.setText(null);
            bmarca.setText(null);
            bmodelo.setText(null);
            btalla.setText(null);
            bcantidad.setText(null);

        } else {
            JOptionPane.showMessageDialog(null, "ESTE PRODUCTO NO ESTA DISPONIBLE","Información",JOptionPane.INFORMATION_MESSAGE);
            codigoUnico.setText(null);
            bnombreUs.setText(null);
            bcontra.setText(null);
            bcolor.setText(null);
            bmarca.setText(null);
            bmodelo.setText(null);
            btalla.setText(null);
            bcantidad.setText(null);
        }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        actualizarTabla(model);//MODIFICA

        // Crear la tabla
        JTable table = new JTable(model);
        //JButton btnSumar = new JButton("Sumar");

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);

        // Configurar Panel
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(800,400));
        panel.add(new JScrollPane(scrollPane), BorderLayout.CENTER);
        //panel.add(btnSumar, BorderLayout.SOUTH);

        JFrame frame = new JFrame("CARRITO");
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }//GEN-LAST:event_btnCarritoActionPerformed

    private void opcVerLosDemasModelos5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcVerLosDemasModelos5MouseClicked
        ListadeProductos menu = new ListadeProductos();
        menu.setVisible(true);
    }//GEN-LAST:event_opcVerLosDemasModelos5MouseClicked
    
    private void actualizarTabla(DefaultTableModel model) {
    // Borramos todos los datos de la tabla
    model.setRowCount(0);

    // Agregamos los datos de todos los productos en el carrito a la tabla
    for (SistemaVentasC5.Producto producto : carrito) {
        Object[] fila = {producto.getCodigoVenta(),producto.getNombre(), producto.getContraseña(),producto.getColor(),producto.getMarca(),
        producto.getModelo(),producto.getTalla(),producto.getCantidad(),producto.getCantidadT(),producto.getTotalT()};
        model.addRow(fila);
    }
 }  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SistemaVentasC5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SistemaVentasC5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SistemaVentasC5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SistemaVentasC5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SistemaVentasC5().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bcantidad;
    private javax.swing.JTextField bcolor;
    private javax.swing.JTextField bcontra;
    private javax.swing.JTextField bmarca;
    private javax.swing.JTextField bmodelo;
    private javax.swing.JTextField bnombreUs;
    private javax.swing.JTextField btalla;
    private javax.swing.JButton btnCarrito;
    private javax.swing.JButton btnComprar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField codigoUnico;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu opcVerLosDemasModelos5;
    private javax.swing.JTable tabElimU;
    private javax.swing.JLabel tfcodigoVenta;
    private javax.swing.JLabel tfcodigoVenta1;
    private javax.swing.JLabel tfcodigoVenta2;
    private javax.swing.JLabel tfcodigoVenta3;
    private javax.swing.JLabel tfcodigoVenta4;
    private javax.swing.JLabel tfcodigoVenta5;
    private javax.swing.JLabel tfcodigoVenta6;
    private javax.swing.JLabel tfcodigoVenta7;
    // End of variables declaration//GEN-END:variables
}
