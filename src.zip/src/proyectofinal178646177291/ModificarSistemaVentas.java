package proyectofinal178646177291;

/*
   FRAME que modifica los datos del area de las Compras realizadas por el usuario
   Esta opción solo la tiene el Administrador
*/

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.jfree.chart.ChartPanel;

import Conexiones.conectar.ConexionSQL;
public class ModificarSistemaVentas extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    private DefaultTableModel model;
    // Configuramos la tabla de productos
   
    ArrayList<Producto> carrito = new ArrayList<>();
    public ModificarSistemaVentas() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos(" ");
    }
    
     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
   public class Producto {
    private String codigoVenta;
    private String nombre;
    private String  contraseña;
    private String color;
    private String  marca;
    private String modelo;
    private float  talla;
    private int cantidad;
    private float  cantT;
    private float  totalT;
    
    public Producto(String codigoVenta,String nombre, String contraseña, String color, String marca, String modelo, float talla, int cantidad, float cantT, float totalT) {
        this.codigoVenta = codigoVenta;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.talla = talla;
        this.cantidad = cantidad;
        this.cantT = cantT;
        this.totalT = totalT;
    }

    public String getCodigoVenta() {
        return codigoVenta;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getContraseña() {
        return contraseña;
    }
    
    public String getColor() {
        return color;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public float getTalla() {
        return talla;
    }
    
    public int getCantidad() {
        return cantidad;
    }
    
    public float getCantidadT() {
        cantT = 2199*cantidad;
        return cantT;
    }
    
    public float getTotalT() {
        totalT = cantT+94.5f;
        return totalT;
    }
}


    public void mostrarClicDatos(){
         int fila=tabCarritoU.getSelectedRow();
        if(fila>=0){
            codigoUnico.setText(tabCarritoU.getValueAt(fila, 0).toString());
            bnombreUs.setText(tabCarritoU.getValueAt(fila, 1).toString());
            bcontra.setText(tabCarritoU.getValueAt(fila, 2).toString());
            bcolor.setText(tabCarritoU.getValueAt(fila, 3).toString());
            bmarca.setText(tabCarritoU.getValueAt(fila, 4).toString());
            bmodelo.setText(tabCarritoU.getValueAt(fila, 5).toString());
            btalla.setText(tabCarritoU.getValueAt(fila, 6).toString());
            bcantidad.setText(tabCarritoU.getValueAt(fila, 7).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
        
       
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnModificar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCarritoU = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        bcolor = new javax.swing.JTextField();
        tfcodigoVenta1 = new javax.swing.JLabel();
        tfcodigoVenta2 = new javax.swing.JLabel();
        bmarca = new javax.swing.JTextField();
        tfcodigoVenta3 = new javax.swing.JLabel();
        bmodelo = new javax.swing.JTextField();
        tfcodigoVenta4 = new javax.swing.JLabel();
        bcantidad = new javax.swing.JTextField();
        tfcodigoVenta5 = new javax.swing.JLabel();
        bnombreUs = new javax.swing.JTextField();
        tfcodigoVenta6 = new javax.swing.JLabel();
        bcontra = new javax.swing.JTextField();
        btalla = new javax.swing.JTextField();
        tfcodigoVenta7 = new javax.swing.JLabel();
        tfcodigoVenta8 = new javax.swing.JLabel();
        codigoUnico = new javax.swing.JTextField();
        btnRegresar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcVerLosDemasModelos = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("MODIFICAR VENTAS");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(590, 10, 220, 50);

        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModificar.setText("MODIFICAR");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificar);
        btnModificar.setBounds(1060, 390, 130, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(550, 20, 260, 30);

        tabCarritoU.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Codigo Venta", "Color", "Marca", "Modelo", "Cantidad", "Cantidad Pagar", "Total Pagar"
            }
        ));
        tabCarritoU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabCarritoUMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabCarritoU);
        if (tabCarritoU.getColumnModel().getColumnCount() > 0) {
            tabCarritoU.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabCarritoU.getColumnModel().getColumn(3).setPreferredWidth(9);
            tabCarritoU.getColumnModel().getColumn(4).setPreferredWidth(16);
            tabCarritoU.getColumnModel().getColumn(5).setPreferredWidth(12);
            tabCarritoU.getColumnModel().getColumn(6).setPreferredWidth(12);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 260, 1000, 210);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Comprar"));

        bcolor.setBackground(new java.awt.Color(255, 204, 153));
        bcolor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcolor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcolorActionPerformed(evt);
            }
        });

        tfcodigoVenta1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta1.setText("Color:");

        tfcodigoVenta2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta2.setText("Marca:");

        bmarca.setBackground(new java.awt.Color(255, 204, 153));
        bmarca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bmarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmarcaActionPerformed(evt);
            }
        });

        tfcodigoVenta3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta3.setText("Modelo:");

        bmodelo.setBackground(new java.awt.Color(255, 204, 153));
        bmodelo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bmodelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodeloActionPerformed(evt);
            }
        });

        tfcodigoVenta4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta4.setText("Cantidad:");

        bcantidad.setBackground(new java.awt.Color(255, 204, 153));
        bcantidad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcantidadActionPerformed(evt);
            }
        });

        tfcodigoVenta5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta5.setText("Nombre Usuario:");

        bnombreUs.setEditable(false);
        bnombreUs.setBackground(new java.awt.Color(255, 204, 153));
        bnombreUs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bnombreUs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnombreUsActionPerformed(evt);
            }
        });

        tfcodigoVenta6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta6.setText("Contraseña");

        bcontra.setBackground(new java.awt.Color(255, 204, 153));
        bcontra.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bcontra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcontraActionPerformed(evt);
            }
        });

        btalla.setBackground(new java.awt.Color(255, 204, 153));
        btalla.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btalla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btallaActionPerformed(evt);
            }
        });

        tfcodigoVenta7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta7.setText("Talla:");

        tfcodigoVenta8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tfcodigoVenta8.setText("Código Venta:");

        codigoUnico.setBackground(new java.awt.Color(255, 204, 153));
        codigoUnico.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        codigoUnico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigoUnicoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(tfcodigoVenta1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bcolor, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(tfcodigoVenta4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(18, Short.MAX_VALUE)
                        .addComponent(tfcodigoVenta8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(codigoUnico, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfcodigoVenta5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bnombreUs, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tfcodigoVenta7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btalla, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(tfcodigoVenta6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bcontra, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 32, Short.MAX_VALUE)
                .addComponent(tfcodigoVenta2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(tfcodigoVenta3)
                .addGap(18, 18, 18)
                .addComponent(bmodelo, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta8)
                        .addComponent(codigoUnico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta3)
                        .addComponent(bmodelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bmarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta2)
                        .addComponent(bcontra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta6)
                        .addComponent(bnombreUs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta5)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfcodigoVenta4)
                        .addComponent(bcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta7)
                        .addComponent(btalla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfcodigoVenta1)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(20, 110, 1020, 120);

        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRegresar.setText("REGRESAR");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar);
        btnRegresar.setBounds(1060, 440, 130, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FondoCuadrosColores.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1220, 490);

        opcVerLosDemasModelos.setText("Ver los Modelos");
        opcVerLosDemasModelos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcVerLosDemasModelosMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcVerLosDemasModelos);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1217, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void mostrarDatos(String Nombre){
        //MOSTRAR DATOS
        String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from compras ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                
                mod.addRow(reg);
            }
            tabCarritoU.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
 
    
   
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
       //EXCEPCIONES PROPIAS
        Excepciones x = new Excepciones();                
        
        try{
            
            x.noNumeros(bmarca.getText(), bmarca);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una marca sin numeros");
        }
        
        try{
            
            x.noNumeros(bmodelo.getText(), bmodelo);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un modelo sin numeros");
            
        }
        
        try{
            
            x.noMinusculas(bcolor.getText(), bcolor);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un color sin minusculas");
            
        }
        
        try{
            
            x.noMayusculas(btalla.getText(), btalla);
            x.noMinusculas(btalla.getText(), btalla);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }                
        
        try{
            
            x.Enteros(bcantidad.getText(), bcantidad);
            
        } catch(NumberFormatException e){
            
            System.out.println("Error en la talla, Ingresa solo numeros"+e);
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingrese solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       java.sql.Statement ss; 
       String SQL = "SELECT * FROM productos  WHERE modelo='"+bmodelo.getText()+"'and talla='"+btalla.getText()+"'and color='"+bcolor.getText()+"'and marca='"+bmarca.getText()+"'and cantidad>'"+0+"'";
        try {
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            if (rs.next()){
              Float precio = Float.parseFloat(rs.getString("precio"));
              Float numP = precio*Float.parseFloat(bcantidad.getText()); 
              Float totalP = numP + 94.5f; 
              String SQLU="UPDATE compras SET codigoVenta='"+codigoUnico.getText()+"',nomUser='"+bnombreUs.getText()+"',contraseña='"+bcontra.getText()+"',color='"+bcolor.getText()+"',marca='"+bmarca.getText()+"',modelo='"+bmodelo.getText()+"',talla='"+btalla.getText()+"',cantidad='"+bcantidad.getText()+"',cantidadPagar='"+numP+"',totalPagar='"+totalP+"' where codigoVenta='"+codigoUnico.getText()+"'and nomUser='"+bnombreUs.getText()+"'and contraseña='"+bcontra.getText()+"'and modelo='"+bmodelo.getText()+"'and marca='"+bmarca.getText()+"' ";
              try{
                
                ss = con.createStatement();
                ss.executeUpdate(SQLU);
                JOptionPane.showMessageDialog(null, "ACTUZALIZADO");
                mostrarDatos(" ");
             }catch(Exception e){
                 JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
             }
        
                 codigoUnico.setText(null);
                 bnombreUs.setText(null);
                 bcontra.setText(null);
                 bcolor.setText(null);
                 bmarca.setText(null);
                 bmodelo.setText(null);
                 btalla.setText(null);
                 bcantidad.setText(null);
            }
              
             
        }catch(SQLException ex){
            Logger.getLogger(ModificarAdmi.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void tabCarritoUMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabCarritoUMouseClicked
        mostrarClicDatos();
    }//GEN-LAST:event_tabCarritoUMouseClicked

    private void bcolorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcolorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcolorActionPerformed

    private void bmarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmarcaActionPerformed

    private void bmodeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmodeloActionPerformed

    private void bcantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcantidadActionPerformed

    private void bnombreUsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnombreUsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bnombreUsActionPerformed

    private void bcontraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcontraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bcontraActionPerformed

    private void btallaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btallaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btallaActionPerformed

    private void opcVerLosDemasModelosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcVerLosDemasModelosMouseClicked
        ListadeProductos menu = new ListadeProductos();
        menu.setVisible(true);
    }//GEN-LAST:event_opcVerLosDemasModelosMouseClicked

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void codigoUnicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigoUnicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoUnicoActionPerformed

   private void actualizarTabla(DefaultTableModel model) {
    // Borramos todos los datos de la tabla
    model.setRowCount(0);

    // Agregamos los datos de todos los productos en el carrito a la tabla
    for (Producto producto : carrito) {
        Object[] fila = {producto.getCodigoVenta(),producto.getNombre(), producto.getContraseña(),producto.getColor(),producto.getMarca(),
        producto.getModelo(),producto.getTalla(),producto.getCantidad(),producto.getCantidadT(),producto.getTotalT()};
        model.addRow(fila);
    }
}
   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModificarSistemaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModificarSistemaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModificarSistemaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModificarSistemaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarSistemaVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bcantidad;
    private javax.swing.JTextField bcolor;
    private javax.swing.JTextField bcontra;
    private javax.swing.JTextField bmarca;
    private javax.swing.JTextField bmodelo;
    private javax.swing.JTextField bnombreUs;
    private javax.swing.JTextField btalla;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JTextField codigoUnico;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu opcVerLosDemasModelos;
    private javax.swing.JTable tabCarritoU;
    private javax.swing.JLabel tfcodigoVenta1;
    private javax.swing.JLabel tfcodigoVenta2;
    private javax.swing.JLabel tfcodigoVenta3;
    private javax.swing.JLabel tfcodigoVenta4;
    private javax.swing.JLabel tfcodigoVenta5;
    private javax.swing.JLabel tfcodigoVenta6;
    private javax.swing.JLabel tfcodigoVenta7;
    private javax.swing.JLabel tfcodigoVenta8;
    // End of variables declaration//GEN-END:variables
}
