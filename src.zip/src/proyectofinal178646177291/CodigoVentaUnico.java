package proyectofinal178646177291;

/*
   FRAME que contiene la creación del "Codigo De Venta Único"
*/

//LIBRERIAS
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.swing.Icon;
import javax.swing.ImageIcon;


public class CodigoVentaUnico extends javax.swing.JFrame {

  
    private Set<String> codigosGenerados;
    
    public CodigoVentaUnico() {
        initComponents();
        nuevoIcono();
        codigosGenerados = new HashSet<>();
        /*
          Usamos HashSet debido a que este contendrá un conjunto de objetos(claves)
          el cual nos permitirá determinar de una manera más fácil si un objeto
          ya esta o no en el conjunto.
        */
    }


     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
     
    //En esta función llevamos a cabo la creación del Codigo De Venta
    public String generarCodigoVenta() {
        /*
           INFORMACIÓN IMPORTANTE:
           * UUID es la abreviatura de "Universal Unique Identifier!, lo que significa 
           que es un identificador único generado por máquina de un cierto rango.
        
        */
        String codigoVenta = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "").substring(0, 8);

        //SIN REPETICIÓN
        while (codigosGenerados.contains(codigoVenta)) {
            codigoVenta = UUID.randomUUID().toString().toUpperCase().replaceAll("-", "").substring(0, 8);
        }

        //Se van agregando los código que ya se generaron (Sin ser repetidos)
        codigosGenerados.add(codigoVenta);
        return codigoVenta;//Returnamos el valor
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnCrearCodigoV = new javax.swing.JButton();
        labelCodigo = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        btnCrearCodigoV.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCrearCodigoV.setText("CREAR CÓDIGO");
        btnCrearCodigoV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearCodigoVActionPerformed(evt);
            }
        });
        jPanel1.add(btnCrearCodigoV);
        btnCrearCodigoV.setBounds(120, 320, 180, 30);

        labelCodigo.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelCodigo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel1.add(labelCodigo);
        labelCodigo.setBounds(190, 160, 280, 120);

        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(320, 320, 180, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietasAmarillo.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 640, 450);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /*Al dir clic en el boton "btnCrearCodigoV" mandamos a llamar a nuestro generador de Código 
      único y se va asignando
    */
    private void btnCrearCodigoVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearCodigoVActionPerformed
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/verificacion.png"));
        CodigoVentaUnico generador = new CodigoVentaUnico();
        String codigoVenta = generador.generarCodigoVenta();
        labelCodigo.setText(codigoVenta);
        
        int response = JOptionPane.showConfirmDialog(this, "Codigo Creado :)", "Mensaje", JOptionPane.OK_CANCEL_OPTION);
        if(response == JOptionPane.OK_OPTION){
            CatalogoUsuarioP menu = new CatalogoUsuarioP();
            menu.setVisible(true);
            menu.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnCrearCodigoVActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed


    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CodigoVentaUnico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CodigoVentaUnico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CodigoVentaUnico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CodigoVentaUnico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CodigoVentaUnico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrearCodigoV;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelCodigo;
    // End of variables declaration//GEN-END:variables
}
