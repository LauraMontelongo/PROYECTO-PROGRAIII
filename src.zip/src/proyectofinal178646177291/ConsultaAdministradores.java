package proyectofinal178646177291;

/*
   FRAME que contiene la consulta de todos los Administradores registrados en nuestra tienda
*/

//LIBRERIAS
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

//PDF
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import javax.swing.ImageIcon;

import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

//CONEXION
import Conexiones.conectar.ConexionSQL;

public class ConsultaAdministradores extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public ConsultaAdministradores() {
        initComponents();
        nuevoIcono();
        mostrarDatos();
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabAdmin = new javax.swing.JTable();
        btnPDF = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("CONSULTA DE ADMINISTRADORES");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(230, 40, 300, 50);

        btnVolver.setBackground(new java.awt.Color(255, 102, 102));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(10, 410, 100, 23);

        tabAdmin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido Materno", "Apellido Paterno", "Puesto", "Edad", "Nombre Usuario", "Contraseña"
            }
        ));
        jScrollPane1.setViewportView(tabAdmin);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 130, 710, 230);

        btnPDF.setBackground(new java.awt.Color(255, 102, 102));
        btnPDF.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPDF.setText("PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });
        jPanel1.add(btnPDF);
        btnPDF.setBounds(130, 410, 100, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoConsultasA.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 730, 450);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 729, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        //Creamos una variable de tipo "Documento" para el PDF
        Document documento = new Document();

        try {
            //Guardamos la ruta de donde estará el pdf
            String ruta = System.getProperty("user.home");
            /* getInstance:
               Utilizado para la creación de clases singleton (solo se creará una instancia de esa clase 
               y otras obtendrán referencia de esa clase). 
            */
            //Direccion de donde guardarlo y el nombre que tendrá
            PdfWriter.getInstance(documento, new FileOutputStream(ruta + "/Downloads/Reporte_Administradores.pdf"));
            //Abrimos el documento
            documento.open();

            
            //Le dammos forma al texto "Font" (Tipo de letra, tamaño ,color).
            Font font = new Font(Font.FontFamily.TIMES_ROMAN, 24, Font.BOLD,BaseColor.GREEN);
            //Creamos un nuevo parrafo con el texto que queremos y la forma (Font)
            Paragraph title = new Paragraph("REPORTE DE ADMINISTRADORES", font);
            title.setAlignment(Paragraph.ALIGN_CENTER);//Lo centramos
            //Se agrega al documento
            documento.add(title);
            
            //AGREGAMOS UN ESPACIO
            Paragraph espacio = new Paragraph(" ", font);
            documento.add(espacio);
            
            //Agregamos al pdf una tabla con 7 columnas
            PdfPTable tabla = new PdfPTable(7);
            //Agregamos una nueva celda(cell) con los titulos de los encabezados
            tabla.addCell("Nombre");
            tabla.addCell("Apellido Materno");
            tabla.addCell("Apellido Paterno");
            tabla.addCell("Puesto");
            tabla.addCell("Edad");
            tabla.addCell("Nombre Usuario");
            tabla.addCell("Contraseña");

            try {

                //Sentencia SQL
                String SQL="select * from administradores";

                java.sql.Statement s = con.createStatement();
                java.sql.ResultSet rs = s.executeQuery (SQL);

                if(rs.next()){

                    do {
                        //Vamos agregando los datos de cada campo de la base de datos a la tabla
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                        tabla.addCell(rs.getString(5));
                        tabla.addCell(rs.getString(6));
                        tabla.addCell(rs.getString(7));
                    } while (rs.next());
                    /*
                      Ya cuando se agrego todo entonces podemos "Guardar/Agregar" esa tabla al PDF
                    */
                    documento.add(tabla);
                }

            } catch (DocumentException | SQLException e) {
            }
            documento.close();
            JOptionPane.showMessageDialog(null, "Pdf Exitoso!");
        } catch (DocumentException | HeadlessException | FileNotFoundException e) {
        }
    }//GEN-LAST:event_btnPDFActionPerformed

    public void mostrarDatos(){
        String[] titulos={"Nombre","Apellido Materno","Apellido Paterno","Puesto","Edad","Nombre Usuario","Contraseña"};
        String[] reg=new String[7];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from administradores";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_materno");
                reg[2]=rs.getString("apellido_paterno");
                reg[3]=rs.getString("puesto");
                reg[4]=rs.getString("edad");
                reg[5]=rs.getString("nombre_usuario");
                reg[6]=rs.getString("contraseña");
                
                mod.addRow(reg);
            }
            tabAdmin.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaAdministradores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaAdministradores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaAdministradores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaAdministradores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaAdministradores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabAdmin;
    // End of variables declaration//GEN-END:variables
}
