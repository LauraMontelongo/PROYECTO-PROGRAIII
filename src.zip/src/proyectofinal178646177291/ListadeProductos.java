package proyectofinal178646177291;


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import Conexiones.conectar.ConexionSQL;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.jfree.chart.ChartUtilities;

public class ListadeProductos extends javax.swing.JFrame {

    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    
    public ListadeProductos() {
        initComponents();
        nuevoIcono();
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        PanelEspecificaciones = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        PanelColores = new javax.swing.JPanel();
        jLabel134 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jLabel137 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        jLabel139 = new javax.swing.JLabel();
        jLabel140 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        jLabel149 = new javax.swing.JLabel();
        jLabel150 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        jLabel156 = new javax.swing.JLabel();
        jLabel157 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jLabel163 = new javax.swing.JLabel();
        jLabel164 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("PRODUCTOS DISPONIBLES");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(440, 0, 240, 50);

        PanelEspecificaciones.setBorder(javax.swing.BorderFactory.createTitledBorder("Especificaciones"));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 51));
        jLabel1.setText("Marca");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 51));
        jLabel3.setText("Modelo");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 51));
        jLabel4.setText("Talla");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 51));
        jLabel5.setText("Color");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel7.setText("Adidas");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel8.setText("SuperStar");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel9.setText("25 , 25.5 , 26");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel10.setText("0T00A");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel11.setText("$2,199");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel12.setText("$94.5");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel13.setText("Adidas");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel14.setText("Marimekko Court Revival");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel15.setText("21, 22.5");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel16.setText("0T00A");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel17.setText("$2,199");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel18.setText("$94.5");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel19.setText("Adidas");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel20.setText("Adidas");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel21.setText("Adidas");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel22.setText("Aqualette Ocean");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel23.setText("23, 25");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel24.setText("0T00A");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel25.setText("$1,499");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel26.setText("$94.5");

        jLabel27.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel27.setText("Ozelia");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel28.setText("21 , 21.5 , 24");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel29.setText("ZR02F");

        jLabel30.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel30.setText("$2,599");

        jLabel31.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel31.setText("$94.5");

        jLabel32.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel32.setText("NMD_R1");

        jLabel33.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel33.setText("25,26");

        jLabel34.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel34.setText("E1F0A");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel35.setText("$94.5");

        jLabel36.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel36.setText("$3,399");

        jLabel37.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel37.setText("Converse");

        jLabel38.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel38.setText("Converse");

        jLabel39.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel39.setText("Converse");

        jLabel40.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel40.setText("Converse");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel41.setText("Converse");

        jLabel42.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel42.setText("AllStar Chuck Taylor ");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel43.setText("23");

        jLabel44.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel44.setText("E1F0A , FF2SS ,   A3WF5");

        jLabel45.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel45.setText("$1,699");

        jLabel46.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel46.setText("$94.5");

        jLabel47.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel47.setText("Lugged Lift Cheeky");

        jLabel48.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel48.setText("Summer Utility Bota");

        jLabel49.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel49.setText("21");

        jLabel50.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel50.setText("22.5");

        jLabel51.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel51.setText("E1F0A , GL7RU , PX3K6");

        jLabel52.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel52.setText("A0JA3 , PS2A0 ,  PX3K6");

        jLabel53.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel53.setText("$1,899");

        jLabel54.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel54.setText("$94.5");

        jLabel55.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel55.setText("$94.5");

        jLabel56.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel56.setText("$2,499");

        jLabel57.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel57.setText("Edge Glow RunStar ");

        jLabel58.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel58.setText("26");

        jLabel59.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel59.setText("AF00A , HK9D1 , A3WF5");

        jLabel60.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel60.setText("$2,999");

        jLabel61.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel61.setText("$94.5");

        jLabel62.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel62.setText("Florals ChuckTaylor ");

        jLabel63.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel63.setText("Converse");

        jLabel64.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel64.setText("Fila");

        jLabel65.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel65.setText("Fila");

        jLabel66.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel66.setText("Fila");

        jLabel67.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel67.setText("Fila");

        jLabel68.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel68.setText("Fila");

        jLabel69.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel69.setText("Nike");

        jLabel70.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel70.setText("Nike");

        jLabel71.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel71.setText("Nike");

        jLabel72.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel72.setText("Nike");

        jLabel73.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel73.setText("23");

        jLabel74.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel74.setText("AF00A , HK9D1 , WP00T");

        jLabel75.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel75.setText("$1,649");

        jLabel76.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel76.setText("$94.5");

        jLabel77.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel77.setText("Chuck70 Oat Milk");

        jLabel78.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel78.setText("Oakmont TR");

        jLabel79.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel79.setText("23.5");

        jLabel80.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel80.setText("24 , 24.5");

        jLabel81.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel81.setText("E1F9A , A3WF5 ");

        jLabel82.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel82.setText("M0MC3");

        jLabel83.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel83.setText("$1,699");

        jLabel84.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel84.setText("$94.5");

        jLabel85.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel85.setText("$94.5");

        jLabel86.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel86.setText("$1,799");

        jLabel87.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel87.setText("Disruptor II Premium");

        jLabel88.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel88.setText("21");

        jLabel89.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel89.setText("AF00A , 0T00A");

        jLabel90.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel90.setText("$1,899");

        jLabel91.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel91.setText("$94.5");

        jLabel92.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel92.setText("Disruptor II Prism Suede");

        jLabel93.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel93.setText("Disruptor III Prism Suede");

        jLabel94.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel94.setText("22.5");

        jLabel95.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel95.setText("23.5 , 24 , 24.5");

        jLabel96.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel96.setText("DD01D");

        jLabel97.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel97.setText("FF2SS");

        jLabel98.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel98.setText("$2,099");

        jLabel99.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel99.setText("$1,799");

        jLabel100.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel100.setText("$94.5");

        jLabel101.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel101.setText("$94.5");

        jLabel102.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel102.setText("Renno NGeneration");

        jLabel103.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel103.setText("21.5 , 23 , 24.5 ");

        jLabel104.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel104.setText("A0JA3");

        jLabel105.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel105.setText("$2,199");

        jLabel106.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel106.setText("$94.5");

        jLabel107.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel107.setText("Nike");

        jLabel108.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel108.setText("Air Force 107 ");

        jLabel109.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel109.setText("Force 1 LV8 1");

        jLabel110.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel110.setText("Air Jordan 1 Mid SE");

        jLabel111.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel111.setText("Chuck70 Oat Milk");

        jLabel112.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel112.setText("Summer Florals ChuckTaylor ");

        jLabel113.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel113.setText("27 , 28.5");

        jLabel114.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel114.setText("25 , 25.5");

        jLabel115.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel115.setText("ZR02F");

        jLabel116.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel116.setText("0T00A");

        jLabel117.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel117.setText("$2,699");

        jLabel118.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel118.setText("$1,401");

        jLabel119.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel119.setText("$94.5");

        jLabel120.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel120.setText("$94.5");

        jLabel121.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel121.setText("22.5, 27 , 27.5");

        jLabel122.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel122.setText("23.5 ,24, 24.5");

        jLabel123.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel123.setText("AF00A");

        jLabel124.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel124.setText("ZR02F");

        jLabel125.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel125.setText("$3,299");

        jLabel126.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel126.setText("$94.5");

        jLabel127.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel127.setText("$94.5");

        jLabel128.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel128.setText("$2,499");

        jLabel129.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel129.setText("24, 25");

        jLabel130.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel130.setText("PX3K6 , E1F9A , WP00T");

        jLabel131.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel131.setText("$3,499");

        jLabel132.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel132.setText("$94.5");

        jLabel133.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel133.setForeground(new java.awt.Color(255, 0, 51));
        jLabel133.setText("Precio");

        jLabel135.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel135.setForeground(new java.awt.Color(255, 0, 51));
        jLabel135.setText("Envio");

        javax.swing.GroupLayout PanelEspecificacionesLayout = new javax.swing.GroupLayout(PanelEspecificaciones);
        PanelEspecificaciones.setLayout(PanelEspecificacionesLayout);
        PanelEspecificacionesLayout.setHorizontalGroup(
            PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel72)
                            .addComponent(jLabel71)
                            .addComponent(jLabel70)
                            .addComponent(jLabel69)
                            .addComponent(jLabel68)
                            .addComponent(jLabel67)
                            .addComponent(jLabel66)
                            .addComponent(jLabel65)
                            .addComponent(jLabel107)
                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                .addGap(66, 66, 66)
                                .addComponent(jLabel112))
                            .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel130, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelEspecificacionesLayout.createSequentialGroup()
                                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel40)
                                        .addComponent(jLabel41)
                                        .addComponent(jLabel63))
                                    .addGap(276, 276, 276)
                                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel81)
                                        .addComponent(jLabel74)
                                        .addComponent(jLabel59)))))
                        .addContainerGap())
                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel19)
                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel21)
                                                    .addComponent(jLabel20)
                                                    .addComponent(jLabel7))
                                                .addGap(37, 37, 37)
                                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel8)
                                                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel22)
                                                        .addComponent(jLabel14))
                                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                                        .addComponent(jLabel32)
                                                        .addGap(72, 72, 72))))
                                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel37)
                                                        .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.TRAILING))
                                                    .addComponent(jLabel39))
                                                .addGap(26, 26, 26)
                                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel42)
                                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel77, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel87, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(39, 39, 39)
                                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel15)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel23)
                                            .addComponent(jLabel28)
                                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel58)
                                            .addComponent(jLabel73)
                                            .addComponent(jLabel79)
                                            .addComponent(jLabel80)
                                            .addComponent(jLabel88)
                                            .addComponent(jLabel94)
                                            .addComponent(jLabel95)
                                            .addComponent(jLabel103)
                                            .addComponent(jLabel113)
                                            .addComponent(jLabel114)
                                            .addComponent(jLabel121)
                                            .addComponent(jLabel122)
                                            .addComponent(jLabel129))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel29)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel44)
                                    .addComponent(jLabel51)
                                    .addComponent(jLabel52))
                                .addGap(50, 50, 50))
                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel64, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(70, 70, 70)
                                        .addComponent(jLabel3)
                                        .addGap(36, 36, 36))
                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel93, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel92, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel102, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel108, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel109, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel110, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel111, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(4, 4, 4)))
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                        .addGap(136, 136, 136)
                                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel89)
                                            .addComponent(jLabel82)
                                            .addComponent(jLabel96)
                                            .addComponent(jLabel97)
                                            .addComponent(jLabel104)
                                            .addComponent(jLabel116)
                                            .addComponent(jLabel124)
                                            .addComponent(jLabel123)
                                            .addComponent(jLabel115)))
                                    .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                        .addGap(47, 47, 47)
                                        .addComponent(jLabel4)
                                        .addGap(104, 104, 104)
                                        .addComponent(jLabel5)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel56)
                            .addComponent(jLabel11)
                            .addComponent(jLabel17)
                            .addComponent(jLabel25)
                            .addComponent(jLabel36)
                            .addComponent(jLabel30)
                            .addComponent(jLabel45)
                            .addComponent(jLabel53)
                            .addComponent(jLabel60)
                            .addComponent(jLabel75)
                            .addComponent(jLabel83)
                            .addComponent(jLabel86)
                            .addComponent(jLabel90)
                            .addComponent(jLabel98)
                            .addComponent(jLabel99)
                            .addComponent(jLabel105)
                            .addComponent(jLabel117)
                            .addComponent(jLabel118)
                            .addComponent(jLabel125)
                            .addComponent(jLabel128)
                            .addComponent(jLabel131)
                            .addComponent(jLabel133))
                        .addGap(34, 34, 34)
                        .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel132)
                                    .addComponent(jLabel126)
                                    .addComponent(jLabel119)
                                    .addComponent(jLabel106)
                                    .addComponent(jLabel100)
                                    .addComponent(jLabel91)
                                    .addComponent(jLabel84)
                                    .addComponent(jLabel76)
                                    .addComponent(jLabel61)
                                    .addComponent(jLabel85)
                                    .addComponent(jLabel101)
                                    .addComponent(jLabel120)
                                    .addComponent(jLabel127))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel135)
                                    .addComponent(jLabel55)
                                    .addComponent(jLabel54)
                                    .addComponent(jLabel46)
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel31)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel12))
                                .addContainerGap(95, Short.MAX_VALUE))))))
        );
        PanelEspecificacionesLayout.setVerticalGroup(
            PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelEspecificacionesLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1)
                    .addComponent(jLabel133)
                    .addComponent(jLabel135))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel27)
                    .addComponent(jLabel28)
                    .addComponent(jLabel29)
                    .addComponent(jLabel30)
                    .addComponent(jLabel31))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel33)
                        .addComponent(jLabel34)
                        .addComponent(jLabel35)
                        .addComponent(jLabel36)
                        .addComponent(jLabel21)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jLabel42)
                    .addComponent(jLabel43)
                    .addComponent(jLabel44)
                    .addComponent(jLabel45)
                    .addComponent(jLabel46))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(jLabel47)
                    .addComponent(jLabel49)
                    .addComponent(jLabel51)
                    .addComponent(jLabel53)
                    .addComponent(jLabel54))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jLabel48)
                    .addComponent(jLabel50)
                    .addComponent(jLabel52)
                    .addComponent(jLabel55)
                    .addComponent(jLabel56))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(jLabel57)
                    .addComponent(jLabel58)
                    .addComponent(jLabel59)
                    .addComponent(jLabel60)
                    .addComponent(jLabel61))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(jLabel62)
                    .addComponent(jLabel73)
                    .addComponent(jLabel74)
                    .addComponent(jLabel75)
                    .addComponent(jLabel76))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel63)
                    .addComponent(jLabel77)
                    .addComponent(jLabel79)
                    .addComponent(jLabel81)
                    .addComponent(jLabel83)
                    .addComponent(jLabel84))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel64)
                    .addComponent(jLabel78)
                    .addComponent(jLabel80)
                    .addComponent(jLabel82)
                    .addComponent(jLabel85)
                    .addComponent(jLabel86))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel65)
                    .addComponent(jLabel87)
                    .addComponent(jLabel88)
                    .addComponent(jLabel89)
                    .addComponent(jLabel90)
                    .addComponent(jLabel91))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel66)
                    .addComponent(jLabel92)
                    .addComponent(jLabel94)
                    .addComponent(jLabel96)
                    .addComponent(jLabel98)
                    .addComponent(jLabel100))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel97, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel67)
                        .addComponent(jLabel93)
                        .addComponent(jLabel95)
                        .addComponent(jLabel99)
                        .addComponent(jLabel101)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel68)
                    .addComponent(jLabel102)
                    .addComponent(jLabel103)
                    .addComponent(jLabel104, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel105)
                    .addComponent(jLabel106))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel69)
                    .addComponent(jLabel108)
                    .addComponent(jLabel113)
                    .addComponent(jLabel116, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel117)
                    .addComponent(jLabel119))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel70)
                    .addComponent(jLabel109)
                    .addComponent(jLabel114)
                    .addComponent(jLabel115)
                    .addComponent(jLabel118)
                    .addComponent(jLabel120))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel71)
                    .addComponent(jLabel110)
                    .addComponent(jLabel121)
                    .addComponent(jLabel123)
                    .addComponent(jLabel125)
                    .addComponent(jLabel126))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel72)
                    .addComponent(jLabel111)
                    .addComponent(jLabel122)
                    .addComponent(jLabel124)
                    .addComponent(jLabel127)
                    .addComponent(jLabel128))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelEspecificacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel107)
                    .addComponent(jLabel112)
                    .addComponent(jLabel129)
                    .addComponent(jLabel130)
                    .addComponent(jLabel131)
                    .addComponent(jLabel132))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel1.add(PanelEspecificaciones);
        PanelEspecificaciones.setBounds(20, 60, 700, 490);

        PanelColores.setBorder(javax.swing.BorderFactory.createTitledBorder("Gama Colores"));

        jLabel134.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N

        jLabel136.setText("0T00A");

        jLabel137.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/cafe.jpg"))); // NOI18N

        jLabel138.setText("ZR02F");

        jLabel139.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/coral.png"))); // NOI18N

        jLabel140.setText("E1F0A");

        jLabel141.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/rosa.png"))); // NOI18N

        jLabel142.setText("E1F9A");

        jLabel143.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/rojo.png"))); // NOI18N

        jLabel144.setText(" FF2SS");

        jLabel147.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/azulClaro.png"))); // NOI18N

        jLabel148.setText("GL7RU");

        jLabel149.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/amarillo.png"))); // NOI18N
        jLabel149.setText(" ");

        jLabel150.setText("PX3K6");

        jLabel151.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/verdeClaro.png"))); // NOI18N

        jLabel152.setText(" PS2A0");

        jLabel153.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/naranja.jpg"))); // NOI18N

        jLabel154.setText(" A0JA3");

        jLabel155.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/negro.png"))); // NOI18N

        jLabel156.setText("AF00A");

        jLabel157.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/verdeFuerte.jpg"))); // NOI18N

        jLabel158.setText("HK9D1");

        jLabel159.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/azulFuerte.png"))); // NOI18N

        jLabel160.setText("A3WF5");

        jLabel145.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/rosaClaro.png"))); // NOI18N

        jLabel146.setText("WP00T");

        jLabel161.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/multicolor.jpg"))); // NOI18N

        jLabel162.setText("M0MC3");

        jLabel163.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coloresModelos/tornasol.jpg"))); // NOI18N

        jLabel164.setText("DD01D");

        javax.swing.GroupLayout PanelColoresLayout = new javax.swing.GroupLayout(PanelColores);
        PanelColores.setLayout(PanelColoresLayout);
        PanelColoresLayout.setHorizontalGroup(
            PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelColoresLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addComponent(jLabel151, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(jLabel141, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addComponent(jLabel157, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(jLabel159, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel145, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31))
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel139, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(jLabel147, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel149, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32))))
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addComponent(jLabel136, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel138, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel156, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addComponent(jLabel158, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel160, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel146, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PanelColoresLayout.createSequentialGroup()
                                .addComponent(jLabel140, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel148, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(PanelColoresLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel143, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel150, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelColoresLayout.createSequentialGroup()
                        .addComponent(jLabel152, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel142, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel144, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel134, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel137, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel155, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))))
            .addGroup(PanelColoresLayout.createSequentialGroup()
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel153, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel154, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel161, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel162, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel164, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel163, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        PanelColoresLayout.setVerticalGroup(
            PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelColoresLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(PanelColoresLayout.createSequentialGroup()
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel134, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel137, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel155, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel136, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel138, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel156, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel157, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel159, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel145, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel158, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel160, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel146, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel139, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel147, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel149, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel140, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel148, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel150, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel151, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel143, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel141, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel152, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel142, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel144, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(PanelColoresLayout.createSequentialGroup()
                            .addComponent(jLabel153, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel154, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(PanelColoresLayout.createSequentialGroup()
                            .addComponent(jLabel161, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(PanelColoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel162, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel164, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel163, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel1.add(PanelColores);
        PanelColores.setBounds(760, 130, 180, 340);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FondoClaro.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 980, 570);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 980, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

  

   
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelColores;
    private javax.swing.JPanel PanelEspecificaciones;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
