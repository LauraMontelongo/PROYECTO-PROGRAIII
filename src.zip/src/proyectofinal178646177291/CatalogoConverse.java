package proyectofinal178646177291;

/*
   FRAME que contiene los modelos disponibles de la Marca de Converse y obtener más información de estos
   además puede recurrir a más opciones como generar su código de venta, cerrar su sesión o
   volver al catalogo principal
*/

import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
public class CatalogoConverse extends javax.swing.JFrame {

    static String nombreA;
    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public CatalogoConverse() {
        initComponents();
        nuevoIcono();
        setLocationRelativeTo(null);
    }

    public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        logoConverseM3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        logoConverseM1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        logoConverseM4 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        logoConverseM2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        logoConverseM5 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        logoConverseM6 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnCatalogoPrincipal1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcCerrarSesion = new javax.swing.JMenu();
        opcCodigoV = new javax.swing.JMenu();
        opcCatPrinc = new javax.swing.JMenu();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        logoConverseM3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Summer Utility Ctas Cx Explore en Bota de Algodón.jpg"))); // NOI18N
        logoConverseM3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM3MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM3);
        logoConverseM3.setBounds(550, 100, 150, 100);

        jLabel4.setBackground(new java.awt.Color(204, 255, 255));
        jLabel4.setFont(new java.awt.Font("Lucida Bright", 1, 40)); // NOI18N
        jLabel4.setText("CONVERSE");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(260, 0, 250, 110);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Summer Utility Ctas Cx ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(570, 230, 140, 30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Clubhouse Chuck Taylor ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(80, 240, 150, 50);

        logoConverseM1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Clubhouse Chuck Taylor All Star en Bota de Lona.jpg"))); // NOI18N
        logoConverseM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM1MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM1);
        logoConverseM1.setBounds(70, 110, 160, 110);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Ctas Lugged Lift Hi Cheeky");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(300, 240, 160, 30);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel10);
        jLabel10.setBounds(290, 230, 170, 50);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText(" Explore en Bota de Algodón");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(550, 250, 160, 30);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Edge Glow RunStar ");
        jPanel1.add(jLabel15);
        jLabel15.setBounds(90, 430, 140, 30);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("All Star en Bota de Lona");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(80, 230, 140, 30);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel8);
        jLabel8.setBounds(70, 230, 150, 50);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel9);
        jLabel9.setBounds(540, 230, 180, 50);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("All Star en Bota de Lona");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(310, 230, 140, 30);

        logoConverseM4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Edge Glow Run Star Motion en Bota de Lona.jpg"))); // NOI18N
        logoConverseM4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM4MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM4);
        logoConverseM4.setBounds(70, 320, 150, 110);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Motion en Bota de Lona");
        jPanel1.add(jLabel16);
        jLabel16.setBounds(80, 450, 140, 30);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(70, 430, 150, 50);

        logoConverseM2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Ctas Lugged Lift Hi Cheeky.jpg"))); // NOI18N
        logoConverseM2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM2MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM2);
        logoConverseM2.setBounds(300, 100, 150, 110);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Chuck 70 Plus Hi Oat Milk");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(560, 440, 160, 30);

        logoConverseM5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Summer Florals Chuck Taylor All Star en Choclo de Lona.jpg"))); // NOI18N
        logoConverseM5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM5MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM5);
        logoConverseM5.setBounds(310, 320, 150, 110);

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Summer Florals Chuck Taylor ");
        jPanel1.add(jLabel21);
        jLabel21.setBounds(310, 430, 170, 30);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("All Star en Choclo de Lona");
        jPanel1.add(jLabel22);
        jLabel22.setBounds(320, 450, 160, 30);

        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel20);
        jLabel20.setBounds(300, 430, 180, 50);

        logoConverseM6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/converseModelos/Chuck 70 Plus Hi Oat Milk.jpg"))); // NOI18N
        logoConverseM6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseM6MouseClicked(evt);
            }
        });
        jPanel1.add(logoConverseM6);
        logoConverseM6.setBounds(550, 310, 150, 110);

        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel23);
        jLabel23.setBounds(540, 430, 180, 50);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Summer Florals Chuck Taylor ");
        jPanel1.add(jLabel24);
        jLabel24.setBounds(550, 420, 170, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, -30, 750, 520);

        btnCatalogoPrincipal1.setBackground(new java.awt.Color(0, 0, 0));
        btnCatalogoPrincipal1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        btnCatalogoPrincipal1.setText("Volver Catalogo Principal");
        btnCatalogoPrincipal1.setAutoscrolls(true);
        btnCatalogoPrincipal1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCatalogoPrincipal1.setContentAreaFilled(false);
        btnCatalogoPrincipal1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnCatalogoPrincipal1.setFocusPainted(false);
        btnCatalogoPrincipal1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCatalogoPrincipal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCatalogoPrincipal1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnCatalogoPrincipal1);
        btnCatalogoPrincipal1.setBounds(170, 20, 190, 20);

        opcCerrarSesion.setText("Cerrar Sesión");
        opcCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCerrarSesionMouseClicked(evt);
            }
        });
        opcCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCerrarSesionActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCerrarSesion);

        opcCodigoV.setText("Código Venta");
        opcCodigoV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCodigoVMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcCodigoVMouseEntered(evt);
            }
        });
        opcCodigoV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCodigoVActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCodigoV);

        opcCatPrinc.setText("Volver Catalogo Principal");
        opcCatPrinc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCatPrincMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcCatPrinc);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void logoConverseM1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM1MouseClicked
        SistemaVentasC1 menu = new SistemaVentasC1();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM1MouseClicked

    private void btnCatalogoPrincipal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCatalogoPrincipal1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCatalogoPrincipal1ActionPerformed

    private void opcCatPrincMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCatPrincMouseClicked
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcCatPrincMouseClicked

    private void opcCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCerrarSesionMouseClicked
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/candadoMensaje.png"));
        JOptionPane.showMessageDialog(null, "SE CERRÓ SESION CORRECTAMENTE","Información",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_opcCerrarSesionMouseClicked

    private void opcCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCerrarSesionActionPerformed
       
    }//GEN-LAST:event_opcCerrarSesionActionPerformed

    private void opcCodigoVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCodigoVActionPerformed
       
    }//GEN-LAST:event_opcCodigoVActionPerformed

    private void logoConverseM6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM6MouseClicked
        SistemaVentasC6 menu = new SistemaVentasC6();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM6MouseClicked

    private void logoConverseM2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM2MouseClicked
        SistemaVentasC2 menu = new SistemaVentasC2();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM2MouseClicked

    private void logoConverseM3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM3MouseClicked
       SistemaVentasC3 menu = new SistemaVentasC3();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM3MouseClicked

    private void logoConverseM4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM4MouseClicked
        SistemaVentasC4 menu = new SistemaVentasC4();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM4MouseClicked

    private void opcCodigoVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCodigoVMouseClicked
          int response = JOptionPane.showConfirmDialog(this, "¿Quieres Continuar? -> Si ya Tienes Codigo Da clic en No", "Codigo Venta Unico", JOptionPane.YES_NO_OPTION);
        if(response == JOptionPane.YES_OPTION){
            CodigoVentaUnico menu = new CodigoVentaUnico();
            menu.setVisible(true);
            menu.setLocationRelativeTo(null);
            this.dispose();
        }else{
            Icon n = new ImageIcon(getClass().getResource("/imgUsuario/compras.png"));
      
            JOptionPane.showMessageDialog(null, "A COMPRAR :)","Mensaje",JOptionPane.INFORMATION_MESSAGE,n);
        }
    }//GEN-LAST:event_opcCodigoVMouseClicked

    private void opcCodigoVMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCodigoVMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_opcCodigoVMouseEntered

    private void logoConverseM5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseM5MouseClicked
        SistemaVentasC5 menu = new SistemaVentasC5();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoConverseM5MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoConverse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoConverse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoConverse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoConverse.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoConverse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCatalogoPrincipal1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoConverseM1;
    private javax.swing.JLabel logoConverseM2;
    private javax.swing.JLabel logoConverseM3;
    private javax.swing.JLabel logoConverseM4;
    private javax.swing.JLabel logoConverseM5;
    private javax.swing.JLabel logoConverseM6;
    private javax.swing.JMenu opcCatPrinc;
    private javax.swing.JMenu opcCerrarSesion;
    private javax.swing.JMenu opcCodigoV;
    // End of variables declaration//GEN-END:variables
}
