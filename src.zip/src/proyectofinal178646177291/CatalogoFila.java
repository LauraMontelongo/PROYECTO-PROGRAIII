package proyectofinal178646177291;

/*
   FRAME que contiene los modelos disponibles de la Marca de Fila y obtener más información de estos
   además puede recurrir a más opciones como generar su código de venta, cerrar su sesión o
   volver al catalogo principal
*/

import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
public class CatalogoFila extends javax.swing.JFrame {

    static String nombreA;
    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public CatalogoFila() {
        initComponents();
        nuevoIcono();
        setLocationRelativeTo(null);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        logoFilaM3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        logoFilaM1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        logoFilaM2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        logoFilaM4 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        logoFilaM5 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcCerrarSesion = new javax.swing.JMenu();
        opcCodigoV = new javax.swing.JMenu();
        opcCatPrinc = new javax.swing.JMenu();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        logoFilaM3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/filaModelos/Disruptor II Prism Suede.png"))); // NOI18N
        logoFilaM3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoFilaM3MouseClicked(evt);
            }
        });
        jPanel1.add(logoFilaM3);
        logoFilaM3.setBounds(540, 100, 180, 100);

        jLabel4.setBackground(new java.awt.Color(204, 255, 255));
        jLabel4.setFont(new java.awt.Font("Lucida Bright", 1, 40)); // NOI18N
        jLabel4.setText("FILA");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(320, 0, 250, 110);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Oakmont TR");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(110, 240, 100, 20);

        logoFilaM1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/filaModelos/Oakmont TR.png"))); // NOI18N
        logoFilaM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoFilaM1MouseClicked(evt);
            }
        });
        jPanel1.add(logoFilaM1);
        logoFilaM1.setBounds(80, 110, 171, 110);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText(" Disruptor II Premium");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(310, 240, 160, 30);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel10);
        jLabel10.setBounds(300, 230, 170, 50);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Disruptor II Prism Suede");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(550, 240, 170, 30);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel8);
        jLabel8.setBounds(80, 230, 150, 50);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel9);
        jLabel9.setBounds(540, 230, 180, 50);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("All Star en Bota de Lona");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(310, 230, 140, 30);

        logoFilaM2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/filaModelos/Disruptor II Premium.png"))); // NOI18N
        logoFilaM2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoFilaM2MouseClicked(evt);
            }
        });
        jPanel1.add(logoFilaM2);
        logoFilaM2.setBounds(300, 110, 169, 100);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Renno N-Generation");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(430, 440, 160, 30);

        logoFilaM4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/filaModelos/Oakmont TR ICE.png"))); // NOI18N
        logoFilaM4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoFilaM4MouseClicked(evt);
            }
        });
        jPanel1.add(logoFilaM4);
        logoFilaM4.setBounds(170, 320, 170, 110);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Disruptor III Prism Suede");
        jPanel1.add(jLabel22);
        jLabel22.setBounds(170, 440, 180, 30);

        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel20);
        jLabel20.setBounds(160, 430, 180, 50);

        logoFilaM5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/filaModelos/Renno NGeneration.png"))); // NOI18N
        logoFilaM5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoFilaM5MouseClicked(evt);
            }
        });
        jPanel1.add(logoFilaM5);
        logoFilaM5.setBounds(420, 310, 170, 110);

        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel23);
        jLabel23.setBounds(410, 430, 180, 50);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, -30, 750, 520);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Summer Florals Chuck Taylor ");
        jPanel1.add(jLabel24);
        jLabel24.setBounds(420, 420, 170, 30);

        opcCerrarSesion.setText("Cerrar Sesión");
        opcCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCerrarSesionMouseClicked(evt);
            }
        });
        opcCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCerrarSesionActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCerrarSesion);

        opcCodigoV.setText("Código Venta");
        opcCodigoV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCodigoVMouseClicked(evt);
            }
        });
        opcCodigoV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCodigoVActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCodigoV);

        opcCatPrinc.setText("Volver Catalogo Principal");
        opcCatPrinc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCatPrincMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcCatPrinc);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void logoFilaM1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoFilaM1MouseClicked
        SistemaVentasF1 menu = new SistemaVentasF1();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoFilaM1MouseClicked

    private void opcCatPrincMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCatPrincMouseClicked
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcCatPrincMouseClicked

    private void opcCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCerrarSesionMouseClicked
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/candadoMensaje.png"));
        JOptionPane.showMessageDialog(null, "SE CERRÓ SESION CORRECTAMENTE","Información",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_opcCerrarSesionMouseClicked

    private void opcCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCerrarSesionActionPerformed
       
    }//GEN-LAST:event_opcCerrarSesionActionPerformed

    private void opcCodigoVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCodigoVActionPerformed
       
    }//GEN-LAST:event_opcCodigoVActionPerformed

    private void logoFilaM2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoFilaM2MouseClicked
        SistemaVentasF2 menu = new SistemaVentasF2();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoFilaM2MouseClicked

    private void logoFilaM3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoFilaM3MouseClicked
        SistemaVentasF3 menu = new SistemaVentasF3();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoFilaM3MouseClicked

    private void logoFilaM4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoFilaM4MouseClicked
        SistemaVentasF4 menu = new SistemaVentasF4();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoFilaM4MouseClicked

    private void logoFilaM5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoFilaM5MouseClicked
        SistemaVentasF5 menu = new SistemaVentasF5();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoFilaM5MouseClicked

    private void opcCodigoVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCodigoVMouseClicked
          int response = JOptionPane.showConfirmDialog(this, "¿Quieres Continuar? -> Si ya Tienes Codigo Da clic en No", "Codigo Venta Unico", JOptionPane.YES_NO_OPTION);
        if(response == JOptionPane.YES_OPTION){
            CodigoVentaUnico menu = new CodigoVentaUnico();
            menu.setVisible(true);
            menu.setLocationRelativeTo(null);
            this.dispose();
        }else{
            Icon n = new ImageIcon(getClass().getResource("/imgUsuario/compras.png"));
      
            JOptionPane.showMessageDialog(null, "A COMPRAR :)","Mensaje",JOptionPane.INFORMATION_MESSAGE,n);
        }
    }//GEN-LAST:event_opcCodigoVMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoFila.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoFila.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoFila.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoFila.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoFila().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoFilaM1;
    private javax.swing.JLabel logoFilaM2;
    private javax.swing.JLabel logoFilaM3;
    private javax.swing.JLabel logoFilaM4;
    private javax.swing.JLabel logoFilaM5;
    private javax.swing.JMenu opcCatPrinc;
    private javax.swing.JMenu opcCerrarSesion;
    private javax.swing.JMenu opcCodigoV;
    // End of variables declaration//GEN-END:variables
}
