package proyectofinal178646177291;

/*
   FRAME que modifica los datos de los productos que están disponibles en el Almacen
*/

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class ModificarProductos extends javax.swing.JFrame {


     ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public ModificarProductos() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos("");
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nomMod = new javax.swing.JTextField();
        lColor = new javax.swing.JLabel();
        modelo = new javax.swing.JTextField();
        lTalla = new javax.swing.JLabel();
        btnModifica = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lTalla1 = new javax.swing.JLabel();
        lTalla2 = new javax.swing.JLabel();
        talla = new javax.swing.JTextField();
        color = new javax.swing.JTextField();
        lTalla4 = new javax.swing.JLabel();
        marca = new javax.swing.JTextField();
        lTalla5 = new javax.swing.JLabel();
        precio = new javax.swing.JTextField();
        cantidad = new javax.swing.JTextField();
        lTalla6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabProd = new javax.swing.JTable();
        lColor1 = new javax.swing.JLabel();
        bmarca = new javax.swing.JTextField();
        lColor2 = new javax.swing.JLabel();
        tallab = new javax.swing.JTextField();
        lColor3 = new javax.swing.JLabel();
        bColor = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("Modificar Datos Productos");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(420, 10, 260, 50);

        nomMod.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(nomMod);
        nomMod.setBounds(170, 100, 190, 22);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setForeground(new java.awt.Color(255, 255, 255));
        lColor.setText("* Nombre de la Marca: ");
        jPanel1.add(lColor);
        lColor.setBounds(20, 60, 160, 20);
        jPanel1.add(modelo);
        modelo.setBounds(200, 240, 140, 22);

        lTalla.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla.setText("Modelo");
        jPanel1.add(lTalla);
        lTalla.setBounds(250, 220, 110, 20);

        btnModifica.setBackground(new java.awt.Color(255, 204, 153));
        btnModifica.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModifica.setText("MODIFICAR");
        btnModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificaActionPerformed(evt);
            }
        });
        jPanel1.add(btnModifica);
        btnModifica.setBounds(200, 420, 160, 30);

        btnVolver.setBackground(new java.awt.Color(255, 204, 153));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(20, 420, 140, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(400, 20, 260, 30);

        lTalla1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla1.setText("Color");
        jPanel1.add(lTalla1);
        lTalla1.setBounds(80, 280, 120, 20);

        lTalla2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla2.setText("Talla");
        jPanel1.add(lTalla2);
        lTalla2.setBounds(250, 280, 70, 20);
        jPanel1.add(talla);
        talla.setBounds(200, 300, 140, 22);
        jPanel1.add(color);
        color.setBounds(30, 300, 140, 22);

        lTalla4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla4.setText("Marca");
        jPanel1.add(lTalla4);
        lTalla4.setBounds(70, 220, 70, 20);
        jPanel1.add(marca);
        marca.setBounds(30, 240, 140, 22);

        lTalla5.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla5.setText("Precio");
        jPanel1.add(lTalla5);
        lTalla5.setBounds(80, 340, 70, 20);
        jPanel1.add(precio);
        precio.setBounds(30, 360, 140, 22);
        jPanel1.add(cantidad);
        cantidad.setBounds(200, 360, 140, 22);

        lTalla6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla6.setText("Cantidad");
        jPanel1.add(lTalla6);
        lTalla6.setBounds(240, 340, 110, 20);

        tabProd.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Marca", "Modelo", "Color", "Talla", "Precio", "Cantidad"
            }
        ));
        tabProd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabProdMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabProd);
        if (tabProd.getColumnModel().getColumnCount() > 0) {
            tabProd.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabProd.getColumnModel().getColumn(2).setPreferredWidth(7);
            tabProd.getColumnModel().getColumn(3).setPreferredWidth(5);
            tabProd.getColumnModel().getColumn(4).setPreferredWidth(7);
            tabProd.getColumnModel().getColumn(5).setPreferredWidth(6);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(370, 80, 970, 402);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setForeground(new java.awt.Color(255, 255, 255));
        lColor1.setText("* Nombre del Modelo: ");
        jPanel1.add(lColor1);
        lColor1.setBounds(20, 100, 160, 20);

        bmarca.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(bmarca);
        bmarca.setBounds(170, 60, 190, 22);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setForeground(new java.awt.Color(255, 255, 255));
        lColor2.setText("* Talla del Modelo: ");
        jPanel1.add(lColor2);
        lColor2.setBounds(20, 140, 160, 20);

        tallab.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(tallab);
        tallab.setBounds(170, 140, 190, 22);

        lColor3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor3.setForeground(new java.awt.Color(255, 255, 255));
        lColor3.setText("* Color del Modelo: ");
        jPanel1.add(lColor3);
        lColor3.setBounds(20, 180, 160, 20);

        bColor.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(bColor);
        bColor.setBounds(170, 180, 190, 22);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoModifU.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1360, 490);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1357, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
           //MOSTRAR DATOS
        String[] titulos={"Marca","Modelo","Color","Talla","Precio","Cantidad"};
        String[] reg=new String[6];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from productos";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("marca");
                reg[1]=rs.getString("modelo");
                reg[2]=rs.getString("color");
                reg[3]=rs.getString("talla");
                reg[4]=rs.getString("precio");
                reg[5]=rs.getString("cantidad");
                
                mod.addRow(reg);
            }
            tabProd.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void modificar(){
        int fila=tabProd.getSelectedRow();
        if(fila>=0){
            bmarca.setText(tabProd.getValueAt(fila, 0).toString());
            nomMod.setText(tabProd.getValueAt(fila, 1).toString());
            marca.setText(tabProd.getValueAt(fila, 0).toString());
            modelo.setText(tabProd.getValueAt(fila, 1).toString());
            color.setText(tabProd.getValueAt(fila, 2).toString());
            bColor.setText(tabProd.getValueAt(fila, 2).toString());
            talla.setText(tabProd.getValueAt(fila, 3).toString());
            tallab.setText(tabProd.getValueAt(fila, 3).toString());
            precio.setText(tabProd.getValueAt(fila, 4).toString());
            cantidad.setText(tabProd.getValueAt(fila, 5).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }

    public void mostrarDatos(){
        String[] titulos={"Marca","Modelo","Color","Talla","Precio","Cantidad"};
        String[] reg=new String[6];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from productos";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("marca");
                reg[1]=rs.getString("modelo");
                reg[2]=rs.getString("color");
                reg[3]=rs.getString("talla");
                reg[4]=rs.getString("precio");
                reg[5]=rs.getString("cantidad");
                
                mod.addRow(reg);
            }
            tabProd.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificaActionPerformed
        //EXCEPCIONES PROPIAS
               
        Excepciones x = new Excepciones();
        
        try{
            
            x.noNumeros(marca.getText(), bmarca);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una marca sin numeros");
            
        }
        
        try{
            
            x.noNumeros(modelo.getText(), modelo);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un modelo sin numeros");
            
        }
        
        try{
            
            x.noMinusculas(color.getText(), color);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un color sin minusculas");
            
        }
        
        try{
            
            x.noMayusculas(talla.getText(), talla);
            x.noMinusculas(talla.getText(), talla);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try{
            
            x.noMayusculas(precio.getText(), precio);
            x.noMinusculas(precio.getText(), precio);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en el precio, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try{
            
            x.Enteros(cantidad.getText(), cantidad);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la cantidad, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String SQLU="UPDATE productos SET marca='"+marca.getText()+"',modelo='"+modelo.getText()+"',color='"+color.getText()+"',talla='"+talla.getText()+"',precio='"+precio.getText()+"',cantidad='"+cantidad.getText()+"' where marca='"+bmarca.getText()+"'and modelo='"+nomMod.getText()+"'and talla='"+tallab.getText()+"'and color='"+bColor.getText()+"' ";
        java.sql.Statement ss; 
        try {
            ss = con.createStatement();
            ss.executeUpdate(SQLU);
            JOptionPane.showMessageDialog(null, "ACTUZALIZADO");
            mostrarDatos();
       
        } catch (SQLException ex) {
            Logger.getLogger(ModificarProductos.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        bmarca.setText(null);
        nomMod.setText(null);
        marca.setText(null);
        modelo.setText(null);
        color.setText(null);
        talla.setText(null);
        precio.setText(null);
        cantidad.setText(null);
        tallab.setText(null);
        bColor.setText(null);
    }//GEN-LAST:event_btnModificaActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabProdMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabProdMouseClicked
        modificar();
    }//GEN-LAST:event_tabProdMouseClicked
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModificarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModificarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModificarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModificarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bColor;
    private javax.swing.JTextField bmarca;
    private javax.swing.JButton btnModifica;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField cantidad;
    private javax.swing.JTextField color;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lColor3;
    private javax.swing.JLabel lTalla;
    private javax.swing.JLabel lTalla1;
    private javax.swing.JLabel lTalla2;
    private javax.swing.JLabel lTalla4;
    private javax.swing.JLabel lTalla5;
    private javax.swing.JLabel lTalla6;
    private javax.swing.JTextField marca;
    private javax.swing.JTextField modelo;
    private javax.swing.JTextField nomMod;
    private javax.swing.JTextField precio;
    private javax.swing.JTable tabProd;
    private javax.swing.JTextField talla;
    private javax.swing.JTextField tallab;
    // End of variables declaration//GEN-END:variables
}
