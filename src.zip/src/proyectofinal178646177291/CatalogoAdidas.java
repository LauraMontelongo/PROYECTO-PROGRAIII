package proyectofinal178646177291;

/*
   FRAME que contiene los modelos disponibles de la Marca de Adidas y obtener más información de estos
   además puede recurrir a más opciones como generar su código de venta, cerrar su sesión o
   volver al catalogo principal
*/
//LIBRERIAS
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/*MANDAMOS A LLAMAR A NUESTRO ARCHIVO DE "Java Pacjage" de la Carpeta conectar para 
  tener una conexión exitosa a la base de datos
*/
import Conexiones.conectar.ConexionSQL;

public class CatalogoAdidas extends javax.swing.JFrame {

    static String nombreA;
    
    //CREAMOS UNA NUEVA CONEXION
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    
    public CatalogoAdidas() {
        initComponents();
        nuevoIcono(); //CAMBIAMOS EL LOGO ORIGIBAL DE JFRAME A UNA NUEVA IMAGEN
        setLocationRelativeTo(null);
    }

    public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        logoAdidasM3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        logoAdidasM1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        logoAdidasM2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        logoAdidasM4 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        logoAdidasM5 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcCerrarSesion = new javax.swing.JMenu();
        opcCodigoV = new javax.swing.JMenu();
        opcCatPrinc = new javax.swing.JMenu();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        logoAdidasM3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adidasModelos/AQUALETTE OCEAN.jpg"))); // NOI18N
        logoAdidasM3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoAdidasM3MouseClicked(evt);
            }
        });
        jPanel1.add(logoAdidasM3);
        logoAdidasM3.setBounds(540, 90, 180, 130);

        jLabel4.setBackground(new java.awt.Color(204, 255, 255));
        jLabel4.setFont(new java.awt.Font("Lucida Bright", 1, 40)); // NOI18N
        jLabel4.setText("ADIDAS");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(290, 0, 250, 110);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText(" 1 '07 Premium");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(110, 250, 100, 20);

        logoAdidasM1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adidasModelos/superstar.jpg"))); // NOI18N
        logoAdidasM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoAdidasM1MouseClicked(evt);
            }
        });
        jPanel1.add(logoAdidasM1);
        logoAdidasM1.setBounds(70, 90, 170, 130);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("  MARIMEKKO COURT REVIVAL");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(300, 240, 180, 30);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel10);
        jLabel10.setBounds(300, 230, 180, 50);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("AQUALETTE OCEAN");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(580, 240, 160, 30);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Nike Air Force");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(120, 230, 80, 30);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel8);
        jLabel8.setBounds(80, 230, 150, 50);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel9);
        jLabel9.setBounds(540, 230, 180, 50);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("All Star en Bota de Lona");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(310, 230, 140, 30);

        logoAdidasM2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adidasModelos/MARIMEKKO COURT REVIVAL.jpg"))); // NOI18N
        logoAdidasM2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoAdidasM2MouseClicked(evt);
            }
        });
        jPanel1.add(logoAdidasM2);
        logoAdidasM2.setBounds(300, 100, 170, 110);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("NMD_R1");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(470, 440, 160, 30);

        logoAdidasM4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adidasModelos/ozelia.jpg"))); // NOI18N
        logoAdidasM4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoAdidasM4MouseClicked(evt);
            }
        });
        jPanel1.add(logoAdidasM4);
        logoAdidasM4.setBounds(170, 280, 170, 150);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Ozelia");
        jPanel1.add(jLabel22);
        jLabel22.setBounds(230, 440, 160, 30);

        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel20);
        jLabel20.setBounds(160, 430, 180, 50);

        logoAdidasM5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adidasModelos/NMD_R1.jpg"))); // NOI18N
        logoAdidasM5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoAdidasM5MouseClicked(evt);
            }
        });
        jPanel1.add(logoAdidasM5);
        logoAdidasM5.setBounds(420, 310, 170, 110);

        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondogris.jpg"))); // NOI18N
        jPanel1.add(jLabel23);
        jLabel23.setBounds(410, 430, 180, 50);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, -30, 750, 520);

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Summer Florals Chuck Taylor ");
        jPanel1.add(jLabel24);
        jLabel24.setBounds(420, 420, 170, 30);

        opcCerrarSesion.setText("Cerrar Sesión");
        opcCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCerrarSesionMouseClicked(evt);
            }
        });
        opcCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCerrarSesionActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCerrarSesion);

        opcCodigoV.setText("Código Venta");
        opcCodigoV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCodigoVMouseClicked(evt);
            }
        });
        opcCodigoV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCodigoVActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCodigoV);

        opcCatPrinc.setText("Volver Catalogo Principal");
        opcCatPrinc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCatPrincMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcCatPrinc);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /* -> EN AQUELLAS FUNCIONES QUE DICEN "logoAdidasA y un número" Son aquellas que nos van a dirigir a
       el catalogo de esa marca al dar clic sobre la imagen
       -> EN AQUELLAS FUNCIONES QUE DICEN "opc" son aquellas que contienen las opciones que tiene el usuario
       para llevar a cabo como cerrar su sesión, checar sus compras realizadas, crear su código de Venta,etc.
    */
    private void logoAdidasM1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoAdidasM1MouseClicked
        SistemaVentasA1 menu = new SistemaVentasA1();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoAdidasM1MouseClicked

    private void opcCatPrincMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCatPrincMouseClicked
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcCatPrincMouseClicked

    private void opcCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCerrarSesionMouseClicked
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/candadoMensaje.png"));
        JOptionPane.showMessageDialog(null, "SE CERRÓ SESION CORRECTAMENTE","Información",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_opcCerrarSesionMouseClicked

    private void opcCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCerrarSesionActionPerformed
       
    }//GEN-LAST:event_opcCerrarSesionActionPerformed

    private void opcCodigoVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCodigoVActionPerformed
     
    }//GEN-LAST:event_opcCodigoVActionPerformed

    private void logoAdidasM2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoAdidasM2MouseClicked
       SistemaVentasA2 menu = new SistemaVentasA2();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoAdidasM2MouseClicked

    private void logoAdidasM3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoAdidasM3MouseClicked
        SistemaVentasA3 menu = new SistemaVentasA3();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoAdidasM3MouseClicked

    private void logoAdidasM5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoAdidasM5MouseClicked
        SistemaVentasA5 menu = new SistemaVentasA5();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoAdidasM5MouseClicked

    private void logoAdidasM4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoAdidasM4MouseClicked
        SistemaVentasA4 menu = new SistemaVentasA4();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_logoAdidasM4MouseClicked

    private void opcCodigoVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCodigoVMouseClicked
        int response = JOptionPane.showConfirmDialog(this, "¿Quieres Continuar? -> Si ya Tienes Codigo Da clic en No", "Codigo Venta Unico", JOptionPane.YES_NO_OPTION);
        if(response == JOptionPane.YES_OPTION){
            CodigoVentaUnico menu = new CodigoVentaUnico();
            menu.setVisible(true);
            menu.setLocationRelativeTo(null);
            this.dispose();
        }else{
            //AGREGAMOS UNA IMAGEN A NUESTRO JOptionPane
            Icon n = new ImageIcon(getClass().getResource("/imgUsuario/compras.png"));
      
            JOptionPane.showMessageDialog(null, "A COMPRAR :)","Mensaje",JOptionPane.INFORMATION_MESSAGE,n);
        }
    }//GEN-LAST:event_opcCodigoVMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoAdidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoAdidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoAdidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoAdidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoAdidas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoAdidasM1;
    private javax.swing.JLabel logoAdidasM2;
    private javax.swing.JLabel logoAdidasM3;
    private javax.swing.JLabel logoAdidasM4;
    private javax.swing.JLabel logoAdidasM5;
    private javax.swing.JMenu opcCatPrinc;
    private javax.swing.JMenu opcCerrarSesion;
    private javax.swing.JMenu opcCodigoV;
    // End of variables declaration//GEN-END:variables
}
