package proyectofinal178646177291;

/*
   FRAME que modifica los datos del perfil del Usuario
*/

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class ModificarPerfilUsuario extends javax.swing.JFrame {


     ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public ModificarPerfilUsuario() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lColor = new javax.swing.JLabel();
        nomU = new javax.swing.JTextField();
        bApellidoP = new javax.swing.JTextField();
        lTalla = new javax.swing.JLabel();
        btnModifica = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lTalla1 = new javax.swing.JLabel();
        lTalla2 = new javax.swing.JLabel();
        bTelefono = new javax.swing.JTextField();
        bPais = new javax.swing.JTextField();
        label = new javax.swing.JLabel();
        bApellidoM = new javax.swing.JTextField();
        lTalla4 = new javax.swing.JLabel();
        bNombre = new javax.swing.JTextField();
        lTalla5 = new javax.swing.JLabel();
        bEdad = new javax.swing.JTextField();
        bDireccion = new javax.swing.JTextField();
        lTalla6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabUser = new javax.swing.JTable();
        label1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        bNomU = new javax.swing.JTextField();
        bContra = new javax.swing.JTextField();
        label3 = new javax.swing.JLabel();
        lColor1 = new javax.swing.JLabel();
        lColor2 = new javax.swing.JLabel();
        apP = new javax.swing.JTextField();
        apM = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("Modificar Perfil");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(510, 10, 260, 50);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setText("*Apellido Materno:");
        jPanel1.add(lColor);
        lColor.setBounds(690, 80, 160, 20);

        nomU.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(nomU);
        nomU.setBounds(150, 80, 190, 22);
        jPanel1.add(bApellidoP);
        bApellidoP.setBounds(200, 160, 140, 22);

        lTalla.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla.setText("Apellido Paterno");
        jPanel1.add(lTalla);
        lTalla.setBounds(220, 140, 110, 20);

        btnModifica.setBackground(new java.awt.Color(255, 204, 153));
        btnModifica.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModifica.setText("MODIFICAR");
        btnModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificaActionPerformed(evt);
            }
        });
        jPanel1.add(btnModifica);
        btnModifica.setBounds(180, 510, 140, 27);

        btnVolver.setBackground(new java.awt.Color(255, 204, 153));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(30, 510, 130, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(450, 20, 260, 30);

        lTalla1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla1.setText("Apellido Materno");
        jPanel1.add(lTalla1);
        lTalla1.setBounds(50, 220, 120, 20);

        lTalla2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla2.setText("Telefono");
        jPanel1.add(lTalla2);
        lTalla2.setBounds(70, 290, 70, 20);
        jPanel1.add(bTelefono);
        bTelefono.setBounds(30, 310, 140, 22);
        jPanel1.add(bPais);
        bPais.setBounds(30, 380, 140, 22);

        label.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        label.setText("Nombre Usuario");
        jPanel1.add(label);
        label.setBounds(220, 350, 110, 20);
        jPanel1.add(bApellidoM);
        bApellidoM.setBounds(30, 240, 140, 22);

        lTalla4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla4.setText("Nombre");
        jPanel1.add(lTalla4);
        lTalla4.setBounds(80, 140, 70, 20);
        jPanel1.add(bNombre);
        bNombre.setBounds(30, 160, 140, 22);

        lTalla5.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla5.setText("Edad");
        jPanel1.add(lTalla5);
        lTalla5.setBounds(250, 220, 70, 20);
        jPanel1.add(bEdad);
        bEdad.setBounds(200, 240, 140, 22);
        jPanel1.add(bDireccion);
        bDireccion.setBounds(200, 310, 140, 22);

        lTalla6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla6.setText("Direccion");
        jPanel1.add(lTalla6);
        lTalla6.setBounds(240, 290, 110, 20);

        tabUser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido Paterno", "Apellido Materno", "Edad", "Telefono", "Direccion", "Pais", "Nombre Usuario", "Contraseña"
            }
        ));
        tabUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabUserMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabUser);
        if (tabUser.getColumnModel().getColumnCount() > 0) {
            tabUser.getColumnModel().getColumn(0).setPreferredWidth(25);
            tabUser.getColumnModel().getColumn(3).setPreferredWidth(8);
            tabUser.getColumnModel().getColumn(4).setPreferredWidth(10);
            tabUser.getColumnModel().getColumn(6).setPreferredWidth(20);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(370, 160, 790, 402);

        label1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        label1.setText("Pais");
        jPanel1.add(label1);
        label1.setBounds(80, 350, 110, 20);

        label2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        label2.setText("Pais");
        jPanel1.add(label2);
        label2.setBounds(80, 350, 110, 20);
        jPanel1.add(bNomU);
        bNomU.setBounds(200, 380, 140, 22);
        jPanel1.add(bContra);
        bContra.setBounds(40, 450, 140, 22);

        label3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        label3.setText("Contraseña");
        jPanel1.add(label3);
        label3.setBounds(70, 430, 110, 20);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setText("*Nombre");
        jPanel1.add(lColor1);
        lColor1.setBounds(80, 80, 160, 20);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setText("*Apellido Paterno:");
        jPanel1.add(lColor2);
        lColor2.setBounds(360, 80, 160, 20);

        apP.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(apP);
        apP.setBounds(480, 80, 190, 22);

        apM.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(apM);
        apM.setBounds(810, 80, 190, 22);

        jButton1.setText("MOSTRAR DATOS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(1020, 80, 140, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietasRosas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1180, 570);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1183, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 569, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
        //MOSTRAR DATOS
        String[] titulos={"Nombre","Apellido Paterno","Apellido Materno","Edad","Telefono","Direccion","Pais","Nombre Usuario","Contraseña"};
        String[] reg=new String[9];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from usuarios WHERE nombre='"+nomU.getText()+"' and apellido_PaternoU='"+apP.getText()+"' and apellido_maternoU='"+apM.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_paternoU");
                reg[2]=rs.getString("apellido_maternoU");
                reg[3]=rs.getString("edad");
                reg[4]=rs.getString("telefono");
                reg[5]=rs.getString("dirreccion");
                reg[6]=rs.getString("pais");
                reg[7]=rs.getString("nombre_user");
                reg[8]=rs.getString("contraseñaU");
                
                mod.addRow(reg);
            }
            tabUser.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void modificar(){
        int fila=tabUser.getSelectedRow();
        if(fila>=0){
            nomU.setText(tabUser.getValueAt(fila, 0).toString());
            apP.setText(tabUser.getValueAt(fila, 1).toString());
            apM.setText(tabUser.getValueAt(fila, 2).toString());
            bNombre.setText(tabUser.getValueAt(fila, 0).toString());
            bApellidoP.setText(tabUser.getValueAt(fila, 1).toString());
            bApellidoM.setText(tabUser.getValueAt(fila, 2).toString());
            bEdad.setText(tabUser.getValueAt(fila, 3).toString());
            bTelefono.setText(tabUser.getValueAt(fila, 4).toString());
            bDireccion.setText(tabUser.getValueAt(fila, 5).toString());
            bPais.setText(tabUser.getValueAt(fila, 6).toString());
            bNomU.setText(tabUser.getValueAt(fila, 7).toString());
            bContra.setText(tabUser.getValueAt(fila, 8).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }

    public void mostrarDatos(){
         String[] titulos={"Nombre","Apellido Paterno","Apellido Materno","Edad","Telefono","Direccion","Pais","Nombre Usuario","Contraseña"};
        String[] reg=new String[9];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from usuarios WHERE nombre='"+nomU.getText()+"' and apellido_PaternoU='"+apP.getText()+"' and apellido_maternoU='"+apM.getText()+"' ";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_paternoU");
                reg[2]=rs.getString("apellido_maternoU");
                reg[3]=rs.getString("edad");
                reg[4]=rs.getString("telefono");
                reg[5]=rs.getString("dirreccion");
                reg[6]=rs.getString("pais");
                reg[7]=rs.getString("nombre_user");
                reg[8]=rs.getString("contraseñaU");
                
                mod.addRow(reg);
            }
            tabUser.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificaActionPerformed
        //EXCEPCIONES PROPIAS
        
        Excepciones x = new Excepciones();
        
        try{
            
            x.noNumeros(bNombre.getText(), bNombre);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un nombre sin numeros");
        }
                
        try{
            
            x.noNumeros(bApellidoM.getText(), bApellidoM);
            
        }catch (Exception e){
           
            JOptionPane.showMessageDialog(null, "Escribe un apellido sin numeros");
            
        }
                
        try{
            
            x.noNumeros(bApellidoP.getText(), bApellidoP);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un apellido sin numeros");
            
        }                
                
        try{
            
            x.Enteros(bEdad.getText(), bEdad);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe la Edad con un numero entero");
        }
                
        try{
            
            x.Enteros(bTelefono.getText(), bTelefono);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe el Telefono con un numero entero");
        }
                
        try{
            
            x.noNumeros(bDireccion.getText(), bDireccion);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una direccion sin numeros");
        } 
                
        try{
            
            x.noNumeros(bPais.getText(), bPais);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un País sin numeros");
            
        }                
        String SQLU="UPDATE usuarios SET nombre='"+bNombre.getText()+"',apellido_paternoU='"+bApellidoP.getText()+"',apellido_maternoU='"+bApellidoM.getText()+"',edad='"+bEdad.getText()+"',telefono='"+bTelefono.getText()+"',dirreccion='"+bDireccion.getText()+"',pais='"+bPais.getText()+"',nombre_user='"+bNomU.getText()+"',contraseñaU='"+bContra.getText()+"' where nombre='"+nomU.getText()+"'and apellido_paternoU='"+apP.getText()+"'and apellido_maternoU='"+apM.getText()+"' ";
        java.sql.Statement ss; 
        try {
            ss = con.createStatement();
            ss.executeUpdate(SQLU);
            JOptionPane.showMessageDialog(null, "ACTUZALIZADO");
            mostrarDatos();
       
        } catch (SQLException ex) {
            Logger.getLogger(ModificarPerfilUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        nomU.setText(null);
        apP.setText(null);
        apM.setText(null);
        bNombre.setText(null);
        bApellidoP.setText(null);
        bApellidoM.setText(null);
        bEdad.setText(null);
        bTelefono.setText(null);
        bDireccion.setText(null);
        bPais.setText(null);
        bNomU.setText(null);
        bContra.setText(null);
    }//GEN-LAST:event_btnModificaActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        CatalogoUsuarioP menu = new CatalogoUsuarioP();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabUserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabUserMouseClicked
        modificar();
    }//GEN-LAST:event_tabUserMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        mostrarDatos("");
    }//GEN-LAST:event_jButton1ActionPerformed
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModificarPerfilUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModificarPerfilUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModificarPerfilUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModificarPerfilUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarPerfilUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apM;
    private javax.swing.JTextField apP;
    private javax.swing.JTextField bApellidoM;
    private javax.swing.JTextField bApellidoP;
    private javax.swing.JTextField bContra;
    private javax.swing.JTextField bDireccion;
    private javax.swing.JTextField bEdad;
    private javax.swing.JTextField bNomU;
    private javax.swing.JTextField bNombre;
    private javax.swing.JTextField bPais;
    private javax.swing.JTextField bTelefono;
    private javax.swing.JButton btnModifica;
    private javax.swing.JButton btnVolver;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lTalla;
    private javax.swing.JLabel lTalla1;
    private javax.swing.JLabel lTalla2;
    private javax.swing.JLabel lTalla4;
    private javax.swing.JLabel lTalla5;
    private javax.swing.JLabel lTalla6;
    private javax.swing.JLabel label;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JTextField nomU;
    private javax.swing.JTable tabUser;
    // End of variables declaration//GEN-END:variables
}
