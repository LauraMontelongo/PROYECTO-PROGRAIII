package proyectofinal178646177291;

/*
   FRAME que Registra/Agrega a nuevos Clientes/Usuario a nuestra Tienda
*/


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;

public class RegistroUsuario extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public RegistroUsuario() {
        initComponents();
        nuevoIcono();
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        bnombre = new javax.swing.JTextField();
        bnombreU = new javax.swing.JLabel();
        buser = new javax.swing.JTextField();
        bapellidoP = new javax.swing.JTextField();
        lPaterno = new javax.swing.JLabel();
        bapellidoM = new javax.swing.JTextField();
        lModelo = new javax.swing.JLabel();
        bedad = new javax.swing.JTextField();
        lColor = new javax.swing.JLabel();
        bdireccion = new javax.swing.JTextField();
        lTalla = new javax.swing.JLabel();
        bcontraseña = new javax.swing.JTextField();
        lPrecio = new javax.swing.JLabel();
        btnRegistro = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        Nombre1 = new javax.swing.JLabel();
        lPaterno1 = new javax.swing.JLabel();
        btelefono = new javax.swing.JTextField();
        bpais = new javax.swing.JTextField();
        lPrecio1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("REGISTRO");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(250, 10, 220, 50);

        bnombre.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnombreActionPerformed(evt);
            }
        });
        jPanel1.add(bnombre);
        bnombre.setBounds(80, 80, 160, 22);

        bnombreU.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        bnombreU.setForeground(new java.awt.Color(204, 0, 153));
        bnombreU.setText("Nombre Usuario");
        jPanel1.add(bnombreU);
        bnombreU.setBounds(350, 250, 122, 20);
        jPanel1.add(buser);
        buser.setBounds(320, 270, 160, 22);

        bapellidoP.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bapellidoP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bapellidoPActionPerformed(evt);
            }
        });
        jPanel1.add(bapellidoP);
        bapellidoP.setBounds(320, 80, 160, 22);

        lPaterno.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lPaterno.setForeground(new java.awt.Color(204, 0, 153));
        lPaterno.setText("Apellido Materno");
        jPanel1.add(lPaterno);
        lPaterno.setBounds(110, 130, 130, 20);
        jPanel1.add(bapellidoM);
        bapellidoM.setBounds(80, 150, 160, 22);

        lModelo.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lModelo.setForeground(new java.awt.Color(204, 0, 153));
        lModelo.setText("Edad");
        jPanel1.add(lModelo);
        lModelo.setBounds(380, 130, 70, 20);
        jPanel1.add(bedad);
        bedad.setBounds(320, 150, 160, 22);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setForeground(new java.awt.Color(204, 0, 153));
        lColor.setText("   Telefono");
        jPanel1.add(lColor);
        lColor.setBounds(120, 190, 80, 20);
        jPanel1.add(bdireccion);
        bdireccion.setBounds(320, 210, 160, 22);

        lTalla.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla.setForeground(new java.awt.Color(204, 0, 153));
        lTalla.setText("Direccion");
        jPanel1.add(lTalla);
        lTalla.setBounds(370, 190, 80, 20);
        jPanel1.add(bcontraseña);
        bcontraseña.setBounds(80, 330, 160, 22);

        lPrecio.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lPrecio.setForeground(new java.awt.Color(204, 0, 153));
        lPrecio.setText("Contraseña Usuario");
        jPanel1.add(lPrecio);
        lPrecio.setBounds(100, 310, 150, 20);

        btnRegistro.setBackground(new java.awt.Color(204, 153, 255));
        btnRegistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRegistro.setText("REGISTRAR");
        btnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistroActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegistro);
        btnRegistro.setBounds(130, 380, 110, 27);

        btnVolver.setBackground(new java.awt.Color(204, 153, 255));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(310, 380, 100, 30);

        Nombre1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        Nombre1.setForeground(new java.awt.Color(204, 0, 153));
        Nombre1.setText("Nombre");
        jPanel1.add(Nombre1);
        Nombre1.setBounds(140, 60, 70, 20);

        lPaterno1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lPaterno1.setForeground(new java.awt.Color(204, 0, 153));
        lPaterno1.setText("Apellido Paterno");
        jPanel1.add(lPaterno1);
        lPaterno1.setBounds(350, 60, 130, 20);
        jPanel1.add(btelefono);
        btelefono.setBounds(80, 210, 160, 22);
        jPanel1.add(bpais);
        bpais.setBounds(80, 270, 160, 22);

        lPrecio1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lPrecio1.setForeground(new java.awt.Color(204, 0, 153));
        lPrecio1.setText(" Pais");
        jPanel1.add(lPrecio1);
        lPrecio1.setBounds(140, 250, 70, 20);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoRegistroCliente.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 540, 420);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void bnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bnombreActionPerformed

    private void bapellidoPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bapellidoPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bapellidoPActionPerformed

    private void btnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistroActionPerformed
        String SQL = null;
        SQL="insert into usuarios(nombre,apellido_paternoU,apellido_maternoU,edad,telefono,dirreccion,pais,nombre_user,contraseñaU) values (?,?,?,?,?,?,?,?,?)";
        
        //EXCEPCIONES PROPIAS
        
        Excepciones x = new Excepciones();
        
        String nombre = bnombre.getText();
        try{
            
            x.noNumeros(nombre, bnombre);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe un nombre sin numeros");
            
        }
        
        String apellidoM = bapellidoM.getText();
        try{
            
            x.noNumeros(apellidoM, bapellidoM);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe un apellido sin numeros");
            
        }
        
        String apellidoP = bapellidoP.getText();
        try{
            
            x.noNumeros(apellidoP, bapellidoP);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe un apellido sin numeros");
            
        }                
        
        String edad = bedad.getText();
        try{
            
            x.Enteros(edad, bedad);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe un numero entero en la Edad");
            
        }
        
        String telefono = btelefono.getText();
        try{
            
            x.Enteros(telefono, btelefono);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe un numero entero en el Telefono");
            
        }
        
        String direccion = bdireccion.getText();
        try{
            
            x.noNumeros(direccion, bdireccion);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe la direccion sin numeros");
            
        } 
        
        String pais = bpais.getText();
        try{
            
            x.noNumeros(pais, bpais);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escibe el pais sin numeros");
            
        } 
        
        try{

            java.sql.PreparedStatement ps=con.prepareStatement(SQL);
            ps.setString(1, bnombre.getText());
            ps.setString(2,bapellidoP.getText());
            ps.setString(3,bapellidoM.getText());
            ps.setInt(4, Integer.parseInt(bedad.getText()));
            ps.setInt(5, Integer.parseInt(btelefono.getText()));
            ps.setString(6,bdireccion.getText());
            ps.setString(7,bpais.getText());
            ps.setString(8,buser.getText());
            ps.setString(9,bcontraseña.getText());
            
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Registro existoso");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
        }
        bnombre.setText(null);
        bapellidoM.setText(null);
        bapellidoP.setText(null);
        bedad.setText(null);
        btelefono.setText(null);
        bdireccion.setText(null);
        bpais.setText(null);
        buser.setText(null);
        bcontraseña.setText(null);
    }//GEN-LAST:event_btnRegistroActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Nombre1;
    private javax.swing.JTextField bapellidoM;
    public javax.swing.JTextField bapellidoP;
    private javax.swing.JTextField bcontraseña;
    private javax.swing.JTextField bdireccion;
    private javax.swing.JTextField bedad;
    public javax.swing.JTextField bnombre;
    private javax.swing.JLabel bnombreU;
    private javax.swing.JTextField bpais;
    private javax.swing.JTextField btelefono;
    private javax.swing.JButton btnRegistro;
    private javax.swing.JButton btnVolver;
    private javax.swing.JTextField buser;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lModelo;
    private javax.swing.JLabel lPaterno;
    private javax.swing.JLabel lPaterno1;
    private javax.swing.JLabel lPrecio;
    private javax.swing.JLabel lPrecio1;
    private javax.swing.JLabel lTalla;
    // End of variables declaration//GEN-END:variables
}
