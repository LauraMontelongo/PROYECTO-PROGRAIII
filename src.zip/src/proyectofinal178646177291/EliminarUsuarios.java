package proyectofinal178646177291;


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class EliminarUsuarios extends javax.swing.JFrame {


     ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public EliminarUsuarios() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos("");
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        apP = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabElimU = new javax.swing.JTable();
        lColor1 = new javax.swing.JLabel();
        lColor2 = new javax.swing.JLabel();
        ElimC = new javax.swing.JTextField();
        lColor3 = new javax.swing.JLabel();
        ElimU = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        ElimU2 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Eliminar Usuarios");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(460, 10, 160, 50);

        apP.setBackground(new java.awt.Color(204, 204, 204));
        apP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        apP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apPActionPerformed(evt);
            }
        });
        jPanel1.add(apP);
        apP.setBounds(170, 260, 170, 22);

        btnEliminar.setBackground(new java.awt.Color(255, 204, 0));
        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar);
        btnEliminar.setBounds(150, 420, 130, 30);

        btnVolver.setBackground(new java.awt.Color(255, 204, 0));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(20, 420, 110, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondorojo.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(400, 20, 260, 30);

        tabElimU.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido Paterno", "Apellido Materno", "Edad", "Telefono", "Direccion", "Pais", " Nombre Usuario", "Contraseña"
            }
        ));
        tabElimU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabElimUMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabElimU);
        if (tabElimU.getColumnModel().getColumnCount() > 0) {
            tabElimU.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabElimU.getColumnModel().getColumn(3).setPreferredWidth(9);
            tabElimU.getColumnModel().getColumn(4).setPreferredWidth(16);
            tabElimU.getColumnModel().getColumn(5).setPreferredWidth(12);
            tabElimU.getColumnModel().getColumn(6).setPreferredWidth(12);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(350, 80, 850, 402);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setText("* Contraseña del Usuario: ");
        jPanel1.add(lColor1);
        lColor1.setBounds(10, 320, 170, 20);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setText("* Apellido Paterno: ");
        jPanel1.add(lColor2);
        lColor2.setBounds(10, 260, 160, 20);

        ElimC.setBackground(new java.awt.Color(204, 204, 204));
        ElimC.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimCActionPerformed(evt);
            }
        });
        jPanel1.add(ElimC);
        ElimC.setBounds(180, 320, 160, 22);

        lColor3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor3.setText("* Nombre del Usuario: ");
        jPanel1.add(lColor3);
        lColor3.setBounds(10, 200, 160, 20);

        ElimU.setBackground(new java.awt.Color(204, 204, 204));
        ElimU.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimUActionPerformed(evt);
            }
        });
        jPanel1.add(ElimU);
        ElimU.setBounds(170, 200, 170, 22);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoEliminar.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1220, 490);

        ElimU2.setBackground(new java.awt.Color(204, 204, 204));
        ElimU2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ElimU2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElimU2ActionPerformed(evt);
            }
        });
        jPanel1.add(ElimU2);
        ElimU2.setBounds(170, 200, 170, 22);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1217, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
           //MOSTRAR DATOS
        String[] titulos={"Nombre","Apellido Paterno","Apellido Materno","Edad","Telefono","Direccion","Pais","Nombre Usuario","Contraseña"};
        String[] reg=new String[9];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from usuarios";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_paternoU");
                reg[2]=rs.getString("apellido_maternoU");
                reg[3]=rs.getString("edad");
                reg[4]=rs.getString("telefono");
                reg[5]=rs.getString("dirreccion");
                reg[6]=rs.getString("pais");
                reg[7]=rs.getString("nombre_user");
                reg[8]=rs.getString("contraseñaU");
                
                mod.addRow(reg);
            }
            tabElimU.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void Eliminar(){
         int fila=tabElimU.getSelectedRow();
        if(fila>=0){
            ElimU.setText(tabElimU.getValueAt(fila, 0).toString());
            apP.setText(tabElimU.getValueAt(fila, 1).toString());
            ElimC.setText(tabElimU.getValueAt(fila, 8).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }

    public void mostrarDatos(){
 String[] titulos={"Nombre","Apellido Paterno","Apellido Materno","Edad","Telefono","Direccion","Pais","Nombre Usuario","Contraseña"};
        String[] reg=new String[9];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from usuarios";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_paternoU");
                reg[2]=rs.getString("apellido_maternoU");
                reg[3]=rs.getString("edad");
                reg[4]=rs.getString("telefono");
                reg[5]=rs.getString("dirreccion");
                reg[6]=rs.getString("pais");
                reg[7]=rs.getString("nombre_user");
                reg[8]=rs.getString("contraseñaU");
                
                mod.addRow(reg);
            }
            tabElimU.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        java.sql.Statement ss; 
        String user = ElimU.getText();
        String pass = ElimC.getText();
        String apellidoP = apP.getText();
        try {
            ss = con.createStatement();
            String sql="DELETE FROM usuarios WHERE nombre='"+user+"'and contraseñaU='"+pass+"'and apellido_paternoU='"+apellidoP+"' ";
            ss.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "ACTUALIZADO");
            mostrarDatos();
       
        } catch (SQLException ex) {
            Logger.getLogger(EliminarUsuarios.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERROR NO SE PUDO ELIMINAR");
        }
        
        apP.setText(null);
        ElimC.setText(null);
        ElimU.setText(null);
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabElimUMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabElimUMouseClicked
        Eliminar();
    }//GEN-LAST:event_tabElimUMouseClicked

    private void apPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apPActionPerformed

    private void ElimCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimCActionPerformed

    private void ElimUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimUActionPerformed

    private void ElimU2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElimU2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ElimU2ActionPerformed
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ElimC;
    private javax.swing.JTextField ElimU;
    private javax.swing.JTextField ElimU2;
    private javax.swing.JTextField apP;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lColor3;
    private javax.swing.JTable tabElimU;
    // End of variables declaration//GEN-END:variables
}
