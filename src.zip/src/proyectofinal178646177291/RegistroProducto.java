package proyectofinal178646177291;

/*
   FRAME que Registra/Agrega nuevos productos al Almacen
*/


import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class RegistroProducto extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public RegistroProducto() {
        initComponents();
        nuevoIcono();
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        bmarca = new javax.swing.JTextField();
        lCantidad = new javax.swing.JLabel();
        bcantidad = new javax.swing.JTextField();
        bmarca1 = new javax.swing.JTextField();
        lMarca = new javax.swing.JLabel();
        bmodelo = new javax.swing.JTextField();
        lModelo = new javax.swing.JLabel();
        bcolor = new javax.swing.JTextField();
        lColor = new javax.swing.JLabel();
        btalla = new javax.swing.JTextField();
        lTalla = new javax.swing.JLabel();
        bprecio = new javax.swing.JTextField();
        lPrecio = new javax.swing.JLabel();
        btnRegistro = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("Registro Nuevo Producto");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(160, 10, 220, 50);

        bmarca.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bmarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmarcaActionPerformed(evt);
            }
        });
        jPanel1.add(bmarca);
        bmarca.setBounds(160, 80, 190, 22);

        lCantidad.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lCantidad.setForeground(new java.awt.Color(204, 0, 153));
        lCantidad.setText("Cantidad");
        jPanel1.add(lCantidad);
        lCantidad.setBounds(360, 310, 100, 20);
        jPanel1.add(bcantidad);
        bcantidad.setBounds(160, 310, 190, 22);

        bmarca1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        bmarca1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bmarca1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmarca1ActionPerformed(evt);
            }
        });
        jPanel1.add(bmarca1);
        bmarca1.setBounds(160, 80, 190, 23);

        lMarca.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lMarca.setForeground(new java.awt.Color(204, 0, 153));
        lMarca.setText("Marca");
        jPanel1.add(lMarca);
        lMarca.setBounds(360, 80, 70, 20);
        jPanel1.add(bmodelo);
        bmodelo.setBounds(160, 130, 190, 22);

        lModelo.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lModelo.setForeground(new java.awt.Color(204, 0, 153));
        lModelo.setText("Modelo");
        jPanel1.add(lModelo);
        lModelo.setBounds(360, 130, 70, 20);
        jPanel1.add(bcolor);
        bcolor.setBounds(160, 180, 190, 22);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setForeground(new java.awt.Color(204, 0, 153));
        lColor.setText("Color");
        jPanel1.add(lColor);
        lColor.setBounds(360, 180, 70, 20);
        jPanel1.add(btalla);
        btalla.setBounds(160, 230, 190, 22);

        lTalla.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla.setForeground(new java.awt.Color(204, 0, 153));
        lTalla.setText("Talla");
        jPanel1.add(lTalla);
        lTalla.setBounds(360, 230, 70, 20);
        jPanel1.add(bprecio);
        bprecio.setBounds(160, 270, 190, 22);

        lPrecio.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lPrecio.setForeground(new java.awt.Color(204, 0, 153));
        lPrecio.setText("Precio");
        jPanel1.add(lPrecio);
        lPrecio.setBounds(360, 270, 70, 20);

        btnRegistro.setBackground(new java.awt.Color(255, 204, 153));
        btnRegistro.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRegistro.setText("REGISTRAR");
        btnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistroActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegistro);
        btnRegistro.setBounds(110, 380, 110, 27);

        btnVolver.setBackground(new java.awt.Color(255, 204, 153));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("Regresar");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(300, 380, 100, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoRegistroProd.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 500, 420);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 501, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void bmarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmarcaActionPerformed

    private void bmarca1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmarca1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bmarca1ActionPerformed

    private void btnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistroActionPerformed
        String SQL = null;
        SQL="insert into productos(marca,modelo,color,talla,precio,cantidad) values (?,?,?,?,?,?)";
         Excepciones x = new Excepciones();
        
        String marca = bmarca.getText();
        try{
            
            x.noNumeros(marca, bmarca);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una marca sin numeros");
            
            
        }
        
        String modelo = bmodelo.getText();
        try{
            
            x.noNumeros(modelo, bmodelo);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una modelo sin numeros");
            
        }
        
        String color = bcolor.getText();
        try{
            
            x.noMinusculas(color, bcolor);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe una color sin minusculas");
            
        }
        
        String talla = btalla.getText();
        try{
            
            x.noMayusculas(talla, btalla);
            x.noMinusculas(talla, btalla);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la talla, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String precio = bprecio.getText();
        try{
            
            x.noMayusculas(precio, bprecio);
            x.noMinusculas(precio, bprecio);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en el precio, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String cantidad = bcantidad.getText();
        try{
            
            x.Enteros(cantidad, bcantidad);
            
        } catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(null, "Error en la cantidad, Ingresa solo numeros"+e);
            
        } catch (Exception ex) {
            Logger.getLogger(RegistroProducto.class.getName()).log(Level.SEVERE, null, ex);
        }

        try{

            java.sql.PreparedStatement ps=con.prepareStatement(SQL);
            ps.setString(1, bmarca.getText());
            ps.setString(2,bmodelo.getText());
            ps.setString(3,bcolor.getText());          
            ps.setFloat(4, Float.parseFloat(btalla.getText()));
            ps.setFloat(5,Float.parseFloat(bprecio.getText()));
            ps.setInt(6, Integer.parseInt(bcantidad.getText()));
            ps.execute();
            
            JOptionPane.showMessageDialog(null, "Registro existoso");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
        }
        bmarca.setText(null);
        bmodelo.setText(null);
        bcolor.setText(null);
        btalla.setText(null);
        bprecio.setText(null);
        bcantidad.setText(null);
    }//GEN-LAST:event_btnRegistroActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bcantidad;
    private javax.swing.JTextField bcolor;
    public javax.swing.JTextField bmarca;
    public javax.swing.JTextField bmarca1;
    private javax.swing.JTextField bmodelo;
    private javax.swing.JTextField bprecio;
    private javax.swing.JTextField btalla;
    private javax.swing.JButton btnRegistro;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lCantidad;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lMarca;
    private javax.swing.JLabel lModelo;
    private javax.swing.JLabel lPrecio;
    private javax.swing.JLabel lTalla;
    // End of variables declaration//GEN-END:variables
}
