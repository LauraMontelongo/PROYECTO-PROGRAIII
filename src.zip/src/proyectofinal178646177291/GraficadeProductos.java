/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal178646177291;

// LIBRERIAS PARA EL GRÁFICO
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

//BASE DATOS
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

//CONEXION
import Conexiones.conectar.ConexionSQL;


/**
 *
 * @author laura
 */
public class GraficadeProductos {
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    
    
    public void graficar(){
        //Guardamos en un arreglos los nombres de los ejes(x ,y) de la gráfica
        String[] columnNames = {"Marca", "Cantidad"};
        /*
           Modelo de tabla que utiliza una JTable
        */
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        
        //SQL Sentencia
        String SQL = "SELECT marca, cantidad FROM productos";
        try{
            java.sql.Statement s = con.createStatement(); 
            //Se ejecuta
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while (rs.next()) {
                //Obtiene de la base de datos todo lo que esta en la parte de "marca" y "cantidad"
                String marca = rs.getString("marca");
                int cantidad = rs.getInt("cantidad");
                Object[] row = {marca,cantidad};
                model.addRow(row);//Se agrega
           }
            
           /*
              En una Tabla se guarda solamente los dos campos que obtuvimos de la base de datos
            */
                
           JTable tablaProductos = new JTable(model); 
           /*
              *DefaultCategoryDataSet:
               Es donde vamos a meter los datos que queremos representar gráficament
           */
           DefaultCategoryDataset dataset = new DefaultCategoryDataset();
           for (int i = 0; i < tablaProductos.getRowCount(); i++) {
              String marca = (String)tablaProductos.getValueAt(i, 0);
              int cantidad = (int) tablaProductos.getValueAt(i, 1);

              dataset.setValue(cantidad, "PRODUCTOS", marca);
           }
           
           //8 Parametros a tomar en cuenta
           JFreeChart chart = ChartFactory.createBarChart(
            "CANTIDAD DE PRODUCTOS",  // Título del gráfico
            "MARCA",      // Etiqueta del eje X
            "CANTIDAD",     // Etiqueta del eje Y
            dataset,                    // Datos
            PlotOrientation.VERTICAL,   // Orientación del gráfico
            true,                      
            /*
              Si se coloca True se colocará una etiqueta debajo del gráfico que indicará que grupo 
              de datos representa cada color. 
            */
            true,  
            /*
               Si se le coloca True, cuando se le pase el ratón por encima aparecerá una pequeña 
               etiqueta que indica el valor que se halla graficado.
            */
            false          
             /*
                Es para agregar urls. Se deja casi exclusivamente para diseños orientados a la web. 
             */
           );
       
            //Creamos un Panel
            JPanel panel = new JPanel(new BorderLayout());
            //Ponemos sus Dimensiones
            panel.setPreferredSize(new Dimension(500,500));
            //Agregamos la tabla a un JScrollPane(Datos) y al panel
            panel.add(new JScrollPane(tablaProductos), BorderLayout.CENTER);
            
            /*Creamos un panel con la clase ChartPanel al cual le pasamos
              como parámetro el gráfico que acabamos de crear*/
            ChartPanel chartPanel = new ChartPanel(chart);
            //Le ponemos las dimensiones del gráfico
            chartPanel.setPreferredSize(new Dimension(400, 400));
            //Se agrega al Panel
            panel.add(chartPanel, BorderLayout.SOUTH);
            
            //Asignamos el Nombre del JFrame ( Ventana ) 
            JFrame frame = new JFrame("Gráfico");
            frame.getContentPane().add(panel);
            frame.pack();
            frame.setVisible(true);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error de registro "+e.getMessage());
        }
        
        
    }
}
