package proyectofinal178646177291;

/*
   FRAME que contiene la página principal refernete al usuario es decir le muestra las marcas
   que tenemos disponibles en nuestra tienda, además tiene una variedad de ocpiones que puede
   manipular como llevar el control de su Carrito de Compras, Hacer compras especificas o generales, etc-
*/

//LIBRERIAS
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
public class CatalogoUsuarioP extends javax.swing.JFrame {

    static String nombreA;
    
    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();
    public CatalogoUsuarioP() {
        initComponents();
        nuevoIcono();
        setLocationRelativeTo(null);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        logoNike = new javax.swing.JLabel();
        logoConverse = new javax.swing.JLabel();
        logoFila = new javax.swing.JLabel();
        logoAdidas = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnNike = new javax.swing.JButton();
        btnLogoAdidas = new javax.swing.JButton();
        btnFila = new javax.swing.JButton();
        btnMasInfConverse = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        opcCerrarSesion = new javax.swing.JMenu();
        opcCodigoVenta = new javax.swing.JMenu();
        opcModPerfil = new javax.swing.JMenu();
        opcComprasRealizadas = new javax.swing.JMenu();
        opcComprasR1 = new javax.swing.JMenu();
        ocpMostrarCarrito = new javax.swing.JMenuItem();
        opcEliminarCarrito = new javax.swing.JMenuItem();
        opcModificarCarrito = new javax.swing.JMenuItem();
        opcComprarC = new javax.swing.JMenu();
        opcVentaGeneral = new javax.swing.JMenu();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Lucida Bright", 1, 40)); // NOI18N
        jLabel2.setText("DISPONIBLES");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(370, 60, 280, 70);

        logoNike.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logos/nike.png"))); // NOI18N
        logoNike.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.add(logoNike);
        logoNike.setBounds(280, 180, 90, 80);

        logoConverse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logos/converse.png"))); // NOI18N
        logoConverse.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        logoConverse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoConverseMouseClicked(evt);
            }
        });
        jPanel1.add(logoConverse);
        logoConverse.setBounds(80, 180, 90, 80);

        logoFila.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logos/fila.png"))); // NOI18N
        logoFila.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.add(logoFila);
        logoFila.setBounds(660, 180, 90, 80);

        logoAdidas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logos/adidas.png"))); // NOI18N
        logoAdidas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.add(logoAdidas);
        logoAdidas.setBounds(470, 180, 90, 80);

        jLabel4.setBackground(new java.awt.Color(204, 255, 255));
        jLabel4.setFont(new java.awt.Font("Lucida Bright", 1, 40)); // NOI18N
        jLabel4.setText("MARCAS ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(170, 40, 200, 110);

        btnNike.setBackground(new java.awt.Color(153, 153, 153));
        btnNike.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnNike.setForeground(new java.awt.Color(255, 255, 255));
        btnNike.setText("Más Información");
        btnNike.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNikeActionPerformed(evt);
            }
        });
        jPanel1.add(btnNike);
        btnNike.setBounds(260, 280, 130, 23);

        btnLogoAdidas.setBackground(new java.awt.Color(153, 153, 153));
        btnLogoAdidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogoAdidas.setForeground(new java.awt.Color(255, 255, 255));
        btnLogoAdidas.setText("Más Información");
        btnLogoAdidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoAdidasActionPerformed(evt);
            }
        });
        jPanel1.add(btnLogoAdidas);
        btnLogoAdidas.setBounds(460, 280, 130, 23);

        btnFila.setBackground(new java.awt.Color(153, 153, 153));
        btnFila.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnFila.setForeground(new java.awt.Color(255, 255, 255));
        btnFila.setText("Más Información");
        btnFila.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilaActionPerformed(evt);
            }
        });
        jPanel1.add(btnFila);
        btnFila.setBounds(650, 280, 130, 23);

        btnMasInfConverse.setBackground(new java.awt.Color(153, 153, 153));
        btnMasInfConverse.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMasInfConverse.setForeground(new java.awt.Color(255, 255, 255));
        btnMasInfConverse.setText("Más Información");
        btnMasInfConverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMasInfConverseActionPerformed(evt);
            }
        });
        jPanel1.add(btnMasInfConverse);
        btnMasInfConverse.setBounds(60, 280, 130, 23);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imgUsuario/fondoGrietas.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, -30, 860, 490);

        opcCerrarSesion.setText("Cerrar Sesión");
        opcCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCerrarSesionMouseClicked(evt);
            }
        });
        opcCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcCerrarSesionActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcCerrarSesion);

        opcCodigoVenta.setText("Codigo de Venta");
        opcCodigoVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcCodigoVentaMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcCodigoVenta);

        opcModPerfil.setText("Modificar Perfil");
        opcModPerfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcModPerfilMouseClicked(evt);
            }
        });
        jMenuBar1.add(opcModPerfil);

        opcComprasRealizadas.setText("Compras Realizadas");
        opcComprasRealizadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcComprasRealizadasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcComprasRealizadasMouseEntered(evt);
            }
        });
        opcComprasRealizadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcComprasRealizadasActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcComprasRealizadas);

        opcComprasR1.setText("Carrito Compras");
        opcComprasR1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcComprasR1MouseClicked(evt);
            }
        });
        opcComprasR1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcComprasR1ActionPerformed(evt);
            }
        });

        ocpMostrarCarrito.setText("Consultar");
        ocpMostrarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ocpMostrarCarritoActionPerformed(evt);
            }
        });
        opcComprasR1.add(ocpMostrarCarrito);

        opcEliminarCarrito.setText("Eliminar");
        opcEliminarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcEliminarCarritoActionPerformed(evt);
            }
        });
        opcComprasR1.add(opcEliminarCarrito);

        opcModificarCarrito.setText("Modificar");
        opcModificarCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcModificarCarritoActionPerformed(evt);
            }
        });
        opcComprasR1.add(opcModificarCarrito);

        jMenuBar1.add(opcComprasR1);

        opcComprarC.setText("Comprar Carrito");
        opcComprarC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcComprarCMouseClicked(evt);
            }
        });
        opcComprarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcComprarCActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcComprarC);

        opcVentaGeneral.setText("Venta General");
        opcVentaGeneral.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcVentaGeneralMouseClicked(evt);
            }
        });
        opcVentaGeneral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcVentaGeneralActionPerformed(evt);
            }
        });
        jMenuBar1.add(opcVentaGeneral);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 856, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void logoConverseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoConverseMouseClicked
        
    }//GEN-LAST:event_logoConverseMouseClicked

    /*
        -> Las funciones que tiene al inicio "btn" son aquellas que nos llevan al catalogo general
           de cada una de las marcas dependiendo de cual quieras seleccior
        -> Las funciones que tiene al inico "opc" son aquellas que contienen las opciones del usuario
           como hacer una venta general , cerrar su sesión, ver sus compras o el contenido de su carrito
    */
    
    private void btnMasInfConverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMasInfConverseActionPerformed
        CatalogoConverse menu = new CatalogoConverse();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/animacionClic.gif"));
      
        JOptionPane.showMessageDialog(null, "HAZ CLIC SOBRE LA IMAGEN DEL MODELO PARA HACER TU COMPRA","Recomendacion",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_btnMasInfConverseActionPerformed

    private void opcCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCerrarSesionMouseClicked
        Inicio menu = new Inicio();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/candadoMensaje.png"));
        JOptionPane.showMessageDialog(null, "SE CERRÓ SESION CORRECTAMENTE","Información",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_opcCerrarSesionMouseClicked

    private void opcCodigoVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcCodigoVentaMouseClicked
        int response = JOptionPane.showConfirmDialog(this, "¿Quieres Continuar? -> Si ya Tienes Codigo Da clic en No", "Codigo Venta Unico", JOptionPane.YES_NO_OPTION);
        if(response == JOptionPane.YES_OPTION){
            CodigoVentaUnico menu = new CodigoVentaUnico();
            menu.setVisible(true);
            menu.setLocationRelativeTo(null);
            this.dispose();
        }else{
            Icon n = new ImageIcon(getClass().getResource("/imgUsuario/compras.png"));
      
            JOptionPane.showMessageDialog(null, "A COMPRAR :)","Mensaje",JOptionPane.INFORMATION_MESSAGE,n);
        }
    }//GEN-LAST:event_opcCodigoVentaMouseClicked

    private void opcModPerfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcModPerfilMouseClicked
      
        ModificarPerfilUsuario menu = new ModificarPerfilUsuario();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcModPerfilMouseClicked

    private void opcComprasRealizadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcComprasRealizadasMouseClicked
        MostrarComprasDelUsuario menu = new MostrarComprasDelUsuario();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcComprasRealizadasMouseClicked

    private void opcComprasRealizadasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcComprasRealizadasMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_opcComprasRealizadasMouseEntered

    private void opcComprasRealizadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcComprasRealizadasActionPerformed
      
    }//GEN-LAST:event_opcComprasRealizadasActionPerformed

    private void opcCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcCerrarSesionActionPerformed
        
    }//GEN-LAST:event_opcCerrarSesionActionPerformed

    private void btnNikeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNikeActionPerformed
        CatalogoNike menu = new CatalogoNike();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/animacionClic.gif"));
      
        JOptionPane.showMessageDialog(null, "HAZ CLIC SOBRE LA IMAGEN DEL MODELO PARA HACER TU COMPRA","Recomendacion",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_btnNikeActionPerformed

    private void btnLogoAdidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoAdidasActionPerformed
        CatalogoAdidas menu = new CatalogoAdidas();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/animacionClic.gif"));
      
        JOptionPane.showMessageDialog(null, "HAZ CLIC SOBRE LA IMAGEN DEL MODELO PARA HACER TU COMPRA","Recomendacion",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_btnLogoAdidasActionPerformed

    private void opcComprasR1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcComprasR1MouseClicked
        
    }//GEN-LAST:event_opcComprasR1MouseClicked

    private void opcComprasR1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcComprasR1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcComprasR1ActionPerformed

    private void btnFilaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilaActionPerformed
        CatalogoFila menu = new CatalogoFila();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
        Icon n = new ImageIcon(getClass().getResource("/imgUsuario/animacionClic.gif"));
      
        JOptionPane.showMessageDialog(null, "HAZ CLIC SOBRE LA IMAGEN DEL MODELO PARA HACER TU COMPRA","Recomendacion",JOptionPane.INFORMATION_MESSAGE,n);
    }//GEN-LAST:event_btnFilaActionPerformed

    private void opcComprarCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcComprarCMouseClicked
        ComprarDelCarrito menu = new ComprarDelCarrito();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
       
    }//GEN-LAST:event_opcComprarCMouseClicked

    private void opcComprarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcComprarCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcComprarCActionPerformed

    private void opcVentaGeneralMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcVentaGeneralMouseClicked
        VentaGeneral menu = new VentaGeneral();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcVentaGeneralMouseClicked

    private void opcVentaGeneralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcVentaGeneralActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcVentaGeneralActionPerformed

    private void opcEliminarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcEliminarCarritoActionPerformed
        EliminarCarritoUser menu = new EliminarCarritoUser();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcEliminarCarritoActionPerformed

    private void ocpMostrarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ocpMostrarCarritoActionPerformed
        ConsultaCarritoUser menu = new ConsultaCarritoUser();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_ocpMostrarCarritoActionPerformed

    private void opcModificarCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcModificarCarritoActionPerformed
        ModificarCarritoUser menu = new ModificarCarritoUser();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_opcModificarCarritoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarioP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarioP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarioP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CatalogoUsuarioP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatalogoUsuarioP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFila;
    private javax.swing.JButton btnLogoAdidas;
    private javax.swing.JButton btnMasInfConverse;
    private javax.swing.JButton btnNike;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel logoAdidas;
    private javax.swing.JLabel logoConverse;
    private javax.swing.JLabel logoFila;
    private javax.swing.JLabel logoNike;
    private javax.swing.JMenuItem ocpMostrarCarrito;
    private javax.swing.JMenu opcCerrarSesion;
    private javax.swing.JMenu opcCodigoVenta;
    private javax.swing.JMenu opcComprarC;
    private javax.swing.JMenu opcComprasR1;
    private javax.swing.JMenu opcComprasRealizadas;
    private javax.swing.JMenuItem opcEliminarCarrito;
    private javax.swing.JMenu opcModPerfil;
    private javax.swing.JMenuItem opcModificarCarrito;
    private javax.swing.JMenu opcVentaGeneral;
    // End of variables declaration//GEN-END:variables
}
