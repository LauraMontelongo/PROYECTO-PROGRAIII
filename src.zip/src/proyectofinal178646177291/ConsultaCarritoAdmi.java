package proyectofinal178646177291;


/*
   FRAME que contiene las "Reservas" de todos los Usuarios registrados en nuestra tienda
*/
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.ImageIcon;
public class ConsultaCarritoAdmi extends javax.swing.JFrame {


    ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public ConsultaCarritoAdmi() {
        initComponents();
        nuevoIcono();
        mostrarDatos();
        this.setLocationRelativeTo(this);
    }

     public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
     
     public void mostrarDatos(){
            String[] titulos={"Codigo Venta","Nombre Usuario","Contraseña","Color","Marca","Modelo","Talla","Cantidad","Cantidad Pagar","Total"};
        String[] reg=new String[10];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from carrocompras";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("codigoVenta");
                reg[1]=rs.getString("nomUser");
                reg[2]=rs.getString("contraseña");
                reg[3]=rs.getString("color");
                reg[4]=rs.getString("marca");
                reg[5]=rs.getString("modelo");
                reg[6]=rs.getString("talla");
                reg[7]=rs.getString("cantidad");
                reg[8]=rs.getString("cantidadPagar");
                reg[9]=rs.getString("totalPagar");
                
                mod.addRow(reg);
            }
            tabCarritoC.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabCarritoC = new javax.swing.JTable();
        btnPDF3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("CARRITO COMPRAS");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(530, 10, 220, 50);

        btnVolver.setBackground(new java.awt.Color(255, 204, 153));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(30, 440, 110, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(480, 20, 260, 30);

        tabCarritoC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Codigo Venta", "Nombre Usuario", "Contraseña", "Color", "Marca", "Modelo", "Talla", "Cantidad", "Cantidad Pagar", "Total Pagar"
            }
        ));
        tabCarritoC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabCarritoCMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabCarritoC);
        if (tabCarritoC.getColumnModel().getColumnCount() > 0) {
            tabCarritoC.getColumnModel().getColumn(0).setPreferredWidth(38);
            tabCarritoC.getColumnModel().getColumn(3).setPreferredWidth(10);
            tabCarritoC.getColumnModel().getColumn(4).setPreferredWidth(17);
            tabCarritoC.getColumnModel().getColumn(5).setPreferredWidth(35);
            tabCarritoC.getColumnModel().getColumn(6).setPreferredWidth(8);
            tabCarritoC.getColumnModel().getColumn(7).setPreferredWidth(6);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 90, 1160, 220);

        btnPDF3.setBackground(new java.awt.Color(255, 204, 153));
        btnPDF3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPDF3.setForeground(new java.awt.Color(255, 255, 255));
        btnPDF3.setText("PDF");
        btnPDF3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDF3ActionPerformed(evt);
            }
        });
        jPanel1.add(btnPDF3);
        btnPDF3.setBounds(160, 440, 110, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/FondoFlores.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1180, 490);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1180, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

 

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabCarritoCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabCarritoCMouseClicked
       
    }//GEN-LAST:event_tabCarritoCMouseClicked

    private void btnPDF3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDF3ActionPerformed
         Document documento6 = new Document();
       
        try {
            String ruta = System.getProperty("user.home");
            PdfWriter.getInstance(documento6, new FileOutputStream(ruta + "/Downloads/Reporte_CarritoAdministrador.pdf"));
            documento6.open();
            
            
            //TITULO DEL PDF
            Font font = new Font(Font.FontFamily.TIMES_ROMAN, 24, Font.BOLD,BaseColor.MAGENTA);
            Paragraph title = new Paragraph("REPORTE CARRITO", font);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            documento6.add(title);
            
            //AGREGAMOS UN ESPACIO
            Paragraph espacio = new Paragraph(" ", font);
            documento6.add(espacio);
            
            PdfPTable tabla = new PdfPTable(10);
            tabla.addCell("Codigo Venta");
            tabla.addCell("Nombre Usuario");
            tabla.addCell("Contraseña");
            tabla.addCell("Color");
            tabla.addCell("Marca");
            tabla.addCell("Modelo");
            tabla.addCell("Talla");
            tabla.addCell("Cantidad");
            tabla.addCell("Cantidad Pagar");
            tabla.addCell("Total Pagar");
            
            
             
            try {
               
                String SQL="select * from carrocompras";
        
        
                java.sql.Statement s = con.createStatement(); 
                java.sql.ResultSet rs = s.executeQuery (SQL);
                
                if(rs.next()){
                                       
                    do {                        
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                        tabla.addCell(rs.getString(5));
                        tabla.addCell(rs.getString(6));
                        tabla.addCell(rs.getString(7));
                        tabla.addCell(rs.getString(8));
                        tabla.addCell(rs.getString(9));
                        tabla.addCell(rs.getString(10));
                    } while (rs.next());
                    documento6.add(tabla);                    
                }
                
            } catch (DocumentException | SQLException e) {
            }
            documento6.close();
            JOptionPane.showMessageDialog(null, "Pdf Exitoso!");
        } catch (DocumentException | HeadlessException | FileNotFoundException e) {
        }
    }//GEN-LAST:event_btnPDF3ActionPerformed
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConsultaCarritoAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConsultaCarritoAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConsultaCarritoAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConsultaCarritoAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConsultaCarritoAdmi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPDF3;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabCarritoC;
    // End of variables declaration//GEN-END:variables
}
