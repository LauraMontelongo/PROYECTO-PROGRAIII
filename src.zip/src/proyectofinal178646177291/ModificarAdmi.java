package proyectofinal178646177291;



/*
   FRAME que modifica los datos de los Administradores
*/
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Conexiones.conectar.ConexionSQL;
import javax.swing.ImageIcon;
public class ModificarAdmi extends javax.swing.JFrame {


     ConexionSQL cc= new ConexionSQL();
    Connection con =(Connection) cc.conexion();

    public ModificarAdmi() {
        initComponents();
        nuevoIcono();
        this.setLocationRelativeTo(this);
        mostrarDatos("");
    }

    public void nuevoIcono(){
        java.awt.Image icono = new ImageIcon(getClass().getResource("/img/Zapato2.jpg")).getImage();
        this.setIconImage(icono);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nomU = new javax.swing.JTextField();
        lColor = new javax.swing.JLabel();
        bApellidoM = new javax.swing.JTextField();
        lTalla = new javax.swing.JLabel();
        btnModifica = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lTalla1 = new javax.swing.JLabel();
        lTalla2 = new javax.swing.JLabel();
        bPuesto = new javax.swing.JTextField();
        bContra = new javax.swing.JTextField();
        lTalla3 = new javax.swing.JLabel();
        bApellidoP = new javax.swing.JTextField();
        lTalla4 = new javax.swing.JLabel();
        bNombre = new javax.swing.JTextField();
        lTalla5 = new javax.swing.JLabel();
        bEdad = new javax.swing.JTextField();
        bNombreU = new javax.swing.JTextField();
        lTalla6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabA = new javax.swing.JTable();
        lColor1 = new javax.swing.JLabel();
        apP = new javax.swing.JTextField();
        lColor2 = new javax.swing.JLabel();
        apM = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium", 1, 18)); // NOI18N
        jLabel2.setText("Modificar Datos Administrador");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(400, 10, 260, 50);

        nomU.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(nomU);
        nomU.setBounds(200, 80, 190, 22);

        lColor.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor.setForeground(new java.awt.Color(255, 255, 255));
        lColor.setText("* Apellido Materno:");
        jPanel1.add(lColor);
        lColor.setBounds(10, 160, 190, 20);
        jPanel1.add(bApellidoM);
        bApellidoM.setBounds(210, 290, 140, 22);

        lTalla.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla.setText("Apellido Materno");
        jPanel1.add(lTalla);
        lTalla.setBounds(220, 270, 110, 20);

        btnModifica.setBackground(new java.awt.Color(255, 204, 153));
        btnModifica.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnModifica.setText("MODIFICAR");
        btnModifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificaActionPerformed(evt);
            }
        });
        jPanel1.add(btnModifica);
        btnModifica.setBounds(180, 450, 130, 27);

        btnVolver.setBackground(new java.awt.Color(255, 204, 153));
        btnVolver.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnVolver.setText("REGRESAR");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVolver);
        btnVolver.setBounds(20, 450, 120, 30);

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoblanco.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(400, 20, 260, 30);

        lTalla1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla1.setText("Apellido Paterno");
        jPanel1.add(lTalla1);
        lTalla1.setBounds(50, 270, 120, 20);

        lTalla2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla2.setText("Puesto");
        jPanel1.add(lTalla2);
        lTalla2.setBounds(260, 320, 70, 20);
        jPanel1.add(bPuesto);
        bPuesto.setBounds(210, 340, 140, 22);
        jPanel1.add(bContra);
        bContra.setBounds(30, 400, 140, 22);

        lTalla3.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla3.setText("Contraseña");
        jPanel1.add(lTalla3);
        lTalla3.setBounds(60, 380, 110, 20);
        jPanel1.add(bApellidoP);
        bApellidoP.setBounds(30, 290, 140, 22);

        lTalla4.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla4.setText("Nombre");
        jPanel1.add(lTalla4);
        lTalla4.setBounds(80, 210, 70, 20);
        jPanel1.add(bNombre);
        bNombre.setBounds(30, 230, 140, 22);

        lTalla5.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla5.setText("Edad");
        jPanel1.add(lTalla5);
        lTalla5.setBounds(80, 320, 70, 20);
        jPanel1.add(bEdad);
        bEdad.setBounds(30, 340, 140, 22);
        jPanel1.add(bNombreU);
        bNombreU.setBounds(210, 400, 140, 22);

        lTalla6.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lTalla6.setText("Nombre Usuario");
        jPanel1.add(lTalla6);
        lTalla6.setBounds(230, 380, 110, 20);

        tabA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido Materno", "Apellido Paterno", "Puesto", "Edad", "Nombre Usuario", "Contraseña"
            }
        ));
        tabA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabA);
        if (tabA.getColumnModel().getColumnCount() > 0) {
            tabA.getColumnModel().getColumn(0).setPreferredWidth(32);
            tabA.getColumnModel().getColumn(1).setPreferredWidth(30);
            tabA.getColumnModel().getColumn(2).setPreferredWidth(30);
            tabA.getColumnModel().getColumn(3).setPreferredWidth(32);
            tabA.getColumnModel().getColumn(4).setPreferredWidth(7);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(410, 80, 700, 402);

        lColor1.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor1.setForeground(new java.awt.Color(255, 255, 255));
        lColor1.setText("* Nombre del Administrador: ");
        jPanel1.add(lColor1);
        lColor1.setBounds(10, 80, 190, 20);

        apP.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(apP);
        apP.setBounds(140, 120, 190, 22);

        lColor2.setFont(new java.awt.Font("Cambria", 1, 14)); // NOI18N
        lColor2.setForeground(new java.awt.Color(255, 255, 255));
        lColor2.setText("* Apellido Paterno:");
        jPanel1.add(lColor2);
        lColor2.setBounds(10, 120, 190, 20);

        apM.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.add(apM);
        apM.setBounds(140, 160, 190, 22);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/fondoModifU.jpg"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(0, 0, 1120, 490);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1120, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void mostrarDatos(String Nombre){
           //MOSTRAR DATOS
        String[] titulos={"Nombre","Apellido Materno","Apellido Paterno","Puesto","Edad","Nombre Usuario","Contraseña"};
        String[] reg=new String[7];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from administradores";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_materno");
                reg[2]=rs.getString("apellido_paterno");
                reg[3]=rs.getString("puesto");
                reg[4]=rs.getString("edad");
                reg[5]=rs.getString("nombre_usuario");
                reg[6]=rs.getString("contraseña");
                
                mod.addRow(reg);
            }
            tabA.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    
    public void modificar(){
        int fila=tabA.getSelectedRow();
        if(fila>=0){
            nomU.setText(tabA.getValueAt(fila, 0).toString());
            apM.setText(tabA.getValueAt(fila, 1).toString());
            apP.setText(tabA.getValueAt(fila, 2).toString());
            bNombre.setText(tabA.getValueAt(fila, 0).toString());
            bApellidoM.setText(tabA.getValueAt(fila, 1).toString());
            bApellidoP.setText(tabA.getValueAt(fila, 2).toString());
            bPuesto.setText(tabA.getValueAt(fila, 3).toString());
            bEdad.setText(tabA.getValueAt(fila, 4).toString());
            bNombreU.setText(tabA.getValueAt(fila, 5).toString());
            bContra.setText(tabA.getValueAt(fila, 6).toString());
        }else{
            JOptionPane.showMessageDialog(null, "Selecciona Una fila");
        }
    }

    public void mostrarDatos(){
        String[] titulos={"Nombre","Apellido Materno","Apellido Paterno","Puesto","Edad","Nombre Usuario","Contraseña"};
        String[] reg=new String[7];
        
        DefaultTableModel mod= new DefaultTableModel(null,titulos);
        String SQL="select * from administradores";
        
        try{
            java.sql.Statement s = con.createStatement(); 
            java.sql.ResultSet rs = s.executeQuery (SQL);
            
            while(rs.next()){
                reg[0]=rs.getString("nombre");
                reg[1]=rs.getString("apellido_materno");
                reg[2]=rs.getString("apellido_paterno");
                reg[3]=rs.getString("puesto");
                reg[4]=rs.getString("edad");
                reg[5]=rs.getString("nombre_usuario");
                reg[6]=rs.getString("contraseña");
                
                mod.addRow(reg);
            }
            tabA.setModel(mod);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error al mostrar datos "+e.getMessage());
        }
    }
    private void btnModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificaActionPerformed
        //EXCEPCIONES PROPIAS
         Excepciones x = new Excepciones();
        
        try{
            
            x.noNumeros(bNombre.getText(), bNombre);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un nombre sin numeros");
            
        }
        
        try{
            
            x.noNumeros(bApellidoM.getText(), bApellidoM);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un apellido sin numeros");
            
        }
        
        try{
            
            x.noNumeros(bApellidoP.getText(), bApellidoP);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un apellido sin numeros");
            
        }                
        
        try{
            
            x.Enteros(bEdad.getText(), bEdad);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un numero entero en la Edad");
            
        }
        
        try{
            
            x.noNumeros(bPuesto.getText(), bPuesto);
            
        }catch (Exception e){
            
            JOptionPane.showMessageDialog(null, "Escribe un puesto sin numeros");
            
        }           
        String SQLU="UPDATE administradores SET nombre='"+bNombre.getText()+"',apellido_materno='"+bApellidoM.getText()+"',apellido_paterno='"+bApellidoP.getText()+"',puesto='"+bPuesto.getText()+"',edad='"+bEdad.getText()+"',nombre_usuario='"+bNombreU.getText()+"',contraseña='"+bContra.getText()+"' where nombre='"+nomU.getText()+"'and apellido_materno='"+apM.getText()+"'and apellido_paterno='"+apP.getText()+"' ";
        java.sql.Statement ss; 
        try {
            ss = con.createStatement();
            ss.executeUpdate(SQLU);
            JOptionPane.showMessageDialog(null, "ACTUZALIZADO");
            mostrarDatos();
       
        } catch (SQLException ex) {
            Logger.getLogger(ModificarAdmi.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        nomU.setText(null);
        apM.setText(null);
        apP.setText(null);
        bNombre.setText(null);
        bApellidoM.setText(null);
        bApellidoP.setText(null);
        bPuesto.setText(null);
        bEdad.setText(null);
        bNombreU.setText(null);
        bContra.setText(null);      
    }//GEN-LAST:event_btnModificaActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        MenuAdministrador menu = new MenuAdministrador();
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tabAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabAMouseClicked
        modificar();
    }//GEN-LAST:event_tabAMouseClicked
    
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModificarAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModificarAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModificarAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModificarAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModificarAdmi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apM;
    private javax.swing.JTextField apP;
    private javax.swing.JTextField bApellidoM;
    private javax.swing.JTextField bApellidoP;
    private javax.swing.JTextField bContra;
    private javax.swing.JTextField bEdad;
    private javax.swing.JTextField bNombre;
    private javax.swing.JTextField bNombreU;
    private javax.swing.JTextField bPuesto;
    private javax.swing.JButton btnModifica;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lColor;
    private javax.swing.JLabel lColor1;
    private javax.swing.JLabel lColor2;
    private javax.swing.JLabel lTalla;
    private javax.swing.JLabel lTalla1;
    private javax.swing.JLabel lTalla2;
    private javax.swing.JLabel lTalla3;
    private javax.swing.JLabel lTalla4;
    private javax.swing.JLabel lTalla5;
    private javax.swing.JLabel lTalla6;
    private javax.swing.JTextField nomU;
    private javax.swing.JTable tabA;
    // End of variables declaration//GEN-END:variables
}
